
1.6.1 / 2020-05-14
==================

  * fix: fix regexp replace scope (#20)

1.6.0 / 2020-02-14
==================

  * feat: add install command after pack package (#18)

1.5.1 / 2020-02-10
==================

  * fix: remove relative path (#17)

1.5.0 / 2020-02-05
==================

  * feat: support before script (#16)

1.4.1 / 2019-11-06
==================

  * 修复ignoreRule问题
  * 修复ignoreRule问题
  * ignoreRule 正则匹配增加额外规则 适配client/_aaa.json case
  * doc: fix constructor args
  * doc: fix constructor args

1.4.0 / 2019-10-30
==================

  * chore: add clean cache method
  * chore: update remote registry
  * chore: add test
  * feat: support npm custom registry

1.3.3 / 2019-10-29
==================

  * chore: fix #12
  * fix: fix object required cache

1.3.2 / 2019-09-11
==================

  * fix(regular replace bug):

1.3.1 / 2019-09-07
==================

  * fix: fix replace match file

1.3.0 / 2019-09-07
==================

  * feat: 增加执行完成后自定义脚本
  * feat: support custom copy rule
  * chore: update readme

1.2.0 / 2019-09-06
==================

  * chore: update case
  * chore: update case
  * feat: add glob pattern

1.1.0 / 2019-08-29
==================

  * feat: support filename replace (#6)

1.0.2 / 2019-08-23
==================

  * Merge pull request #5 from midwayjs/empty_dir
  * feat: support generate in a empty dir
  * 支持当前目录初始化代码 (#3)

1.0.1 / 2019-08-19
==================

  * fix: get npm package before get path (#2)
  * chore: add history file

1.0.0 / 2019-08-19
==================

  * Merge pull request #1 from midwayjs/dev
  * chore: update readme
  * chore: update readme
  * test: add npm generator test case
  * feat: local generator complete
  * chore: update rule readme
  * chore: update rule readme
  * chore: update readme
  * feat: add generator
