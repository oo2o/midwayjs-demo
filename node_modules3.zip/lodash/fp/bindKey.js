var convert = require('./convert'),
    func = convert('bindKey', require('../bindKey'));

func.placeholder = require('./placeholder');
module.exports = func;
