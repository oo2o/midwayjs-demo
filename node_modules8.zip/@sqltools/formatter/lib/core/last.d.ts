declare const last: (arr?: any[]) => any;
export default last;
