declare function escapeRegExp(str?: string): string;
export default escapeRegExp;
