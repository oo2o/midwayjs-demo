# Installation
> `npm install --save @types/depd`

# Summary
This package contains type definitions for depd (https://github.com/dougwilson/nodejs-depd).

# Details
Files were exported from https://www.github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/depd

Additional Details
 * Last updated: Thu, 07 Sep 2017 22:03:13 GMT
 * Dependencies: node
 * Global values: none

# Credits
These definitions were written by Zhiyuan Wang <https://github.com/danny8002>, BendingBender <https://github.com/BendingBender>.
