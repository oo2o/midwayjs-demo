# Installation
> `npm install --save @types/istanbul-lib-coverage`

# Summary
This package contains type definitions for istanbul-lib-coverage (https://istanbul.js.org).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/istanbul-lib-coverage.

### Additional Details
 * Last updated: Tue, 09 Jun 2020 16:25:43 GMT
 * Dependencies: none
 * Global values: none

# Credits
These definitions were written by [Jason Cheatham](https://github.com/jason0x43), and [Lorenzo Rapetti](https://github.com/loryman).
