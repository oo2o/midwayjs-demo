# Installation
> `npm install --save @types/http-errors`

# Summary
This package contains type definitions for http-errors (https://github.com/jshttp/http-errors).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/http-errors.

### Additional Details
 * Last updated: Fri, 10 Jul 2020 14:16:15 GMT
 * Dependencies: none
 * Global values: none

# Credits
These definitions were written by [Tanguy Krotoff](https://github.com/tkrotoff), and [BendingBender](https://github.com/BendingBender).
