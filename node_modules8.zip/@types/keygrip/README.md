# Installation
> `npm install --save @types/keygrip`

# Summary
This package contains type definitions for keygrip (https://github.com/crypto-utils/keygrip).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/keygrip.

### Additional Details
 * Last updated: Thu, 26 Dec 2019 18:59:55 GMT
 * Dependencies: none
 * Global values: none

# Credits
These definitions were written by jKey Lu (https://github.com/jkeylu).
