# Installation
> `npm install --save @types/debug`

# Summary
This package contains type definitions for debug (https://github.com/visionmedia/debug).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/debug

Additional Details
 * Last updated: Thu, 04 Oct 2018 17:46:11 GMT
 * Dependencies: none
 * Global values: debug

# Credits
These definitions were written by Seon-Wook Park <https://github.com/swook>, Gal Talmor <https://github.com/galtalmor>, John McLaughlin <https://github.com/zamb3zi>, Brasten Sager <https://github.com/brasten>.
