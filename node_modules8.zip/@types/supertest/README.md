# Installation
> `npm install --save @types/supertest`

# Summary
This package contains type definitions for SuperTest (https://github.com/visionmedia/supertest).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/supertest.

### Additional Details
 * Last updated: Mon, 29 Jun 2020 17:37:12 GMT
 * Dependencies: [@types/superagent](https://npmjs.com/package/@types/superagent)
 * Global values: none

# Credits
These definitions were written by [Alex Varju](https://github.com/varju), and [Petteri Parkkila](https://github.com/pietu).
