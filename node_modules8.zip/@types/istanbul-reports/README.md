# Installation
> `npm install --save @types/istanbul-reports`

# Summary
This package contains type definitions for istanbul-reports (https://github.com/istanbuljs/istanbuljs).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/istanbul-reports.

### Additional Details
 * Last updated: Mon, 20 Jul 2020 21:55:27 GMT
 * Dependencies: [@types/istanbul-lib-report](https://npmjs.com/package/@types/istanbul-lib-report)
 * Global values: none

# Credits
These definitions were written by [Jason Cheatham](https://github.com/jason0x43), and [Elena Shcherbakova](https://github.com/not-a-doctor).
