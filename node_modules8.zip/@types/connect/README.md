# Installation
> `npm install --save @types/connect`

# Summary
This package contains type definitions for connect (https://github.com/senchalabs/connect).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/connect.

### Additional Details
 * Last updated: Tue, 08 Dec 2020 20:44:59 GMT
 * Dependencies: [@types/node](https://npmjs.com/package/@types/node)
 * Global values: none

# Credits
These definitions were written by [Maxime LUCE](https://github.com/SomaticIT), and [Evan Hahn](https://github.com/EvanHahn).
