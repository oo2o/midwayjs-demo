# Installation
> `npm install --save @types/power-assert-formatter`

# Summary
This package contains type definitions for power-assert-formatter (https://github.com/twada/power-assert-formatter).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/power-assert-formatter.

### Additional Details
 * Last updated: Mon, 01 Jun 2020 23:34:59 GMT
 * Dependencies: none
 * Global values: `powerAssertFormatter`

# Credits
These definitions were written by [vvakame](https://github.com/vvakame).
