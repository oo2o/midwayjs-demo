# Installation
> `npm install --save @types/content-disposition`

# Summary
This package contains type definitions for content-disposition (https://github.com/jshttp/content-disposition).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/content-disposition.

### Additional Details
 * Last updated: Tue, 31 Mar 2020 22:24:18 GMT
 * Dependencies: none
 * Global values: none

# Credits
These definitions were written by [Stefan Reichel](https://github.com/bomret), and [Piotr Błażejewicz](https://github.com/peterblazejewicz).
