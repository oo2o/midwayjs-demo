# Installation
> `npm install --save @types/range-parser`

# Summary
This package contains type definitions for range-parser (https://github.com/jshttp/range-parser).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/range-parser

Additional Details
 * Last updated: Fri, 07 Dec 2018 19:21:52 GMT
 * Dependencies: none
 * Global values: none

# Credits
These definitions were written by Tomek Łaziuk <https://github.com/tlaziuk>.
