
3.6.0 / 2019-04-24
==================

**features**
  * [[`39c0f1d`](http://github.com/node-modules/sdk-base/commit/39c0f1d946bd7da1e393d42cca2f5e1bc22eb785)] - feat: implement close function (#17) (killa <<killa123@126.com>>)

3.5.1 / 2018-09-27
==================

**fixes**
  * [[`de262c1`](http://github.com/node-modules/sdk-base/commit/de262c1e41e65a5fb11e95a95f96c6c561cb9d23)] - fix(ts): support es module export (#15) (Haoliang Gao <<sakura9515@gmail.com>>)

3.5.0 / 2018-07-26
==================

**features**
  * [[`dcce360`](http://github.com/node-modules/sdk-base/commit/dcce360d5da6a3f0516c2329c1902c49221ffd29)] - feat: add typescript definition file (#14) (Angela <<idu.angela@gmail.com>>)

**others**
  * [[`f975763`](http://github.com/node-modules/sdk-base/commit/f975763047a461fc8d0758f08dd52e16078f5bc9)] - chore: release 3.4.0 (xiaochen.gaoxc <<xiaochen.gaoxc@alibaba-inc.com>>),

3.4.0 / 2017-11-24
==================

**features**
  * [[`98207ba`]](https://github.com/node-modules/sdk-base/pull/11/commits/98207ba521487df39f7c9b116aaf7163bb6b9ad8) - feat: add awaitFirst api (#11) (gxcsoccer <<gxcsoccer@126.com>>)

3.3.0 / 2017-09-17
==================

**features**
  * [[`8d5c04a`](http://github.com/node-modules/sdk-base/commit/8d5c04aa3b0fee135dcf972b447aba0f79f56417)] - feat: add isReady getter (#10) (fengmk2 <<fengmk2@gmail.com>>)

**others**
  * [[`6ec435f`](http://github.com/node-modules/sdk-base/commit/6ec435f676395726ff64646518b55c7c8ff4bc45)] - chore: fix initMethod document description (fengmk2 <<fengmk2@gmail.com>>)

3.2.0 / 2017-06-26
==================

  * feat: let options.initMethod support functions that return promise (#9)

3.1.1 / 2017-03-14
==================

  * fix: avoid duplicate error handler (#8)

3.1.0 / 2017-02-17
==================

  * feat: support client.await (#7)

3.0.1 / 2017-01-12
==================

  * fix: initMethod should be lazy executed (#6)

3.0.0 / 2017-01-12
==================

  * feat: [BREAKING_CHANGE] add ready with error and generator listener (#5)

2.0.1 / 2016-03-11
==================

  * fix: use event.listeners

2.0.0 / 2016-03-11
==================

  * refactor: listen on error synchronous

1.1.0 / 2015-11-14
==================

  * refactor: drop 0.8 support
  * feat: support ready(flagOrFunction)

1.0.1 / 2014-11-06
==================

  * remove .npmignore
  * add __filename, always show construct name
  * more pretty
  * refine error display
  * refactor(error): improve default error handler
  * fix travis
  * fix link
