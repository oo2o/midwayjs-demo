declare function swapCase (value: string, locale?: string): string;

export = swapCase;
