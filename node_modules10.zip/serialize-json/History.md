
1.0.3 / 2018-10-29
==================

**fixes**
  * [[`52d05f7`](http://github.com/node-modules/serialize-json/commit/52d05f7ebe925bd17e7a76aa98f38f7b9babf673)] - fix: avoid big parent in sliced string (#7) (zōng yǔ <<gxcsoccer@users.noreply.github.com>>)

**others**
  * [[`25184dd`](http://github.com/node-modules/serialize-json/commit/25184dd779f11f0b7202b1922bc262162a57c964)] - chore: release 1.0.2 (xiaochen.gaoxc <<xiaochen.gaoxc@alibaba-inc.com>>),

1.0.2 / 2017-09-22
==================

  * refactor: enhance encode/decode large array performance (#4)

1.0.1 / 2017-02-09
==================

  * fix: support encode object without prototype (#2)

1.0.0 / 2017-02-06
==================

 * feat: implement a serialize algorithm for JSON
