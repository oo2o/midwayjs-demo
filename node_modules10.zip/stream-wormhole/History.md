
1.1.0 / 2018-08-15
==================

**features**
  * [[`53ec1b2`](http://github.com/node-modules/stream-wormhole/commit/53ec1b21d0847c5c2d32391f60302cc9e96461f4)] - feat: support piped read stream (fengmk2 <<fengmk2@gmail.com>>)

**fixes**
  * [[`b2b1aaf`](http://github.com/node-modules/stream-wormhole/commit/b2b1aaf4dcd7741c13b76449ed9ef604a34e1f35)] - fix: should removeListener error handlers (fengmk2 <<fengmk2@gmail.com>>)

1.0.4 / 2018-07-17
==================

**fixes**
  * [[`968c008`](http://github.com/node-modules/stream-wormhole/commit/968c0088d18bbaaee7feaced306fd50f891d1743)] - fix: should resume stream first (#5) (fengmk2 <<fengmk2@gmail.com>>)

1.0.3 / 2016-07-25
==================

  * chore: remove black-hole dep (#1)

1.0.2 / 2016-07-15
==================

  * fix: black-hole-stream should be deps

1.0.1 / 2016-07-15
==================

  * fix: should not throw error by default

1.0.0 / 2016-07-15
==================

  * init version
