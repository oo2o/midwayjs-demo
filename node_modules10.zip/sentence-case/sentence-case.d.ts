declare function sentenceCase (value: string, locale?: string, mergeNumbers?: boolean): string;

export = sentenceCase;
