
1.4.1 / 2020-08-19
==================

  * fix: more package analysis (#12)

1.4.0 / 2020-08-06
==================

  * feat: support common dir prefix (#11)

1.3.2 / 2020-06-23
==================

  * fix: jsx type assert parse error (#10)

1.3.1 / 2020-06-15
==================

  * fix: fix request-promise (#9)

1.3.0 / 2020-05-23
==================

  * fix: fix dep with sequelize-typescript (#8)
  * fix: add dot (#7)

1.2.1 / 2020-03-11
==================

  * fix: catch analyze dependencies error (#6)

1.2.0 / 2020-02-16
==================

  * chore: update readme
  * fix: ignore pattern (#5)

1.1.1 / 2020-02-14
==================

  * fix: survive through cyclic symlinks (#4)

1.1.0 / 2020-02-07
==================

  * feat: Support pkg options (#3)

1.0.3 / 2020-01-09
==================

  * chore: export interface (#2)

1.0.2 / 2020-01-08
==================

  * feat: add using dependencies analyze (#1)

1.0.1 / 2020-01-02
==================

  * chore: clean publish code

1.0.0 / 2020-01-02
==================

  * feat: first add
