# Change Log

All notable changes to this project will be documented in this file.
See [Conventional Commits](https://conventionalcommits.org) for commit guidelines.

## [2.6.13](https://github.com/midwayjs/midway/compare/v2.6.12...v2.6.13) (2021-01-21)

**Note:** Version bump only for package @midwayjs/bootstrap





## [2.6.10](https://github.com/midwayjs/midway/compare/v2.6.9...v2.6.10) (2021-01-10)


### Bug Fixes

* bootstrap missing create logger ([#797](https://github.com/midwayjs/midway/issues/797)) ([f7aac5f](https://github.com/midwayjs/midway/commit/f7aac5fcd9a59a3a36856af58c17ee1d0c9dfca4))





## [2.6.9](https://github.com/midwayjs/midway/compare/v2.6.8...v2.6.9) (2021-01-08)

**Note:** Version bump only for package @midwayjs/bootstrap





## [2.6.8](https://github.com/midwayjs/midway/compare/v2.6.7...v2.6.8) (2021-01-06)

**Note:** Version bump only for package @midwayjs/bootstrap





## [2.6.7](https://github.com/midwayjs/midway/compare/v2.6.6...v2.6.7) (2021-01-05)

**Note:** Version bump only for package @midwayjs/bootstrap





## [2.6.6](https://github.com/midwayjs/midway/compare/v2.6.5...v2.6.6) (2021-01-04)

**Note:** Version bump only for package @midwayjs/bootstrap





## [2.6.5](https://github.com/midwayjs/midway/compare/v2.6.4...v2.6.5) (2021-01-04)

**Note:** Version bump only for package @midwayjs/bootstrap





## [2.6.4](https://github.com/midwayjs/midway/compare/v2.6.3...v2.6.4) (2021-01-02)

**Note:** Version bump only for package @midwayjs/bootstrap





## [2.6.3](https://github.com/midwayjs/midway/compare/v2.6.2...v2.6.3) (2020-12-30)

**Note:** Version bump only for package @midwayjs/bootstrap





## [2.6.2](https://github.com/midwayjs/midway/compare/v2.6.1...v2.6.2) (2020-12-30)

**Note:** Version bump only for package @midwayjs/bootstrap





## [2.6.1](https://github.com/midwayjs/midway/compare/v2.6.0...v2.6.1) (2020-12-29)

**Note:** Version bump only for package @midwayjs/bootstrap





# [2.6.0](https://github.com/midwayjs/midway/compare/v2.5.5...v2.6.0) (2020-12-28)


### Features

* add midway logger ([#743](https://github.com/midwayjs/midway/issues/743)) ([13e8cc7](https://github.com/midwayjs/midway/commit/13e8cc753d994e6f9f073688e22527f75d39984a))





## [2.5.5](https://github.com/midwayjs/midway/compare/v2.5.4...v2.5.5) (2020-12-15)

**Note:** Version bump only for package @midwayjs/bootstrap





## [2.5.2](https://github.com/midwayjs/midway/compare/v2.5.1...v2.5.2) (2020-12-04)

**Note:** Version bump only for package @midwayjs/bootstrap





# [2.5.0](https://github.com/midwayjs/midway/compare/v2.4.8...v2.5.0) (2020-11-28)

**Note:** Version bump only for package @midwayjs/bootstrap





## [2.4.7](https://github.com/midwayjs/midway/compare/v2.4.6...v2.4.7) (2020-11-23)

**Note:** Version bump only for package @midwayjs/bootstrap





## [2.4.5](https://github.com/midwayjs/midway/compare/v2.4.4...v2.4.5) (2020-11-19)

**Note:** Version bump only for package @midwayjs/bootstrap





## [2.4.3](https://github.com/midwayjs/midway/compare/v2.4.2...v2.4.3) (2020-11-16)

**Note:** Version bump only for package @midwayjs/bootstrap





## [2.4.2](https://github.com/midwayjs/midway/compare/v2.4.1...v2.4.2) (2020-11-13)

**Note:** Version bump only for package @midwayjs/bootstrap





## [2.4.1](https://github.com/midwayjs/midway/compare/v2.4.0...v2.4.1) (2020-11-12)

**Note:** Version bump only for package @midwayjs/bootstrap





# [2.4.0](https://github.com/midwayjs/midway/compare/v2.3.23...v2.4.0) (2020-11-11)


### Features

* support define custom egg framework ([#709](https://github.com/midwayjs/midway/issues/709)) ([f5baba1](https://github.com/midwayjs/midway/commit/f5baba18d10e3dc91ba9651effadd00b8f66cf8b))





## [2.3.23](https://github.com/midwayjs/midway/compare/v2.3.22...v2.3.23) (2020-11-03)

**Note:** Version bump only for package @midwayjs/bootstrap





## [2.3.22](https://github.com/midwayjs/midway/compare/v2.3.21...v2.3.22) (2020-10-31)

**Note:** Version bump only for package @midwayjs/bootstrap





## [2.3.20](https://github.com/midwayjs/midway/compare/v2.3.19...v2.3.20) (2020-10-29)

**Note:** Version bump only for package @midwayjs/bootstrap





## [2.3.19](https://github.com/midwayjs/midway/compare/v2.3.18...v2.3.19) (2020-10-28)

**Note:** Version bump only for package @midwayjs/bootstrap





## [2.3.18](https://github.com/midwayjs/midway/compare/v2.3.17...v2.3.18) (2020-10-27)


### Bug Fixes

* configuration inject plugin and more in production environment ([#680](https://github.com/midwayjs/midway/issues/680)) ([41bce5d](https://github.com/midwayjs/midway/commit/41bce5d8a60a6fde61ff62794612eecff2e260ed))





## [2.3.17](https://github.com/midwayjs/midway/compare/v2.3.16...v2.3.17) (2020-10-22)

**Note:** Version bump only for package @midwayjs/bootstrap





## [2.3.15](https://github.com/midwayjs/midway/compare/v2.3.14...v2.3.15) (2020-10-15)

**Note:** Version bump only for package @midwayjs/bootstrap





## [2.3.14](https://github.com/midwayjs/midway/compare/v2.3.13...v2.3.14) (2020-10-15)

**Note:** Version bump only for package @midwayjs/bootstrap





## [2.3.13](https://github.com/midwayjs/midway/compare/v2.3.12...v2.3.13) (2020-10-13)

**Note:** Version bump only for package @midwayjs/bootstrap





## [2.3.11](https://github.com/midwayjs/midway/compare/v2.3.10...v2.3.11) (2020-10-08)

**Note:** Version bump only for package @midwayjs/bootstrap





## [2.3.10](https://github.com/midwayjs/midway/compare/v2.3.9...v2.3.10) (2020-10-08)


### Bug Fixes

* component inject global object and add case ([#663](https://github.com/midwayjs/midway/issues/663)) ([e768ee8](https://github.com/midwayjs/midway/commit/e768ee872ed9855252346920318a32133328c0fe))





## [2.3.9](https://github.com/midwayjs/midway/compare/v2.3.8...v2.3.9) (2020-10-05)

**Note:** Version bump only for package @midwayjs/bootstrap





## [2.3.8](https://github.com/midwayjs/midway/compare/v2.3.7...v2.3.8) (2020-10-05)

**Note:** Version bump only for package @midwayjs/bootstrap





## [2.3.7](https://github.com/midwayjs/midway/compare/v2.3.6...v2.3.7) (2020-10-04)

**Note:** Version bump only for package @midwayjs/bootstrap





## [2.3.6](https://github.com/midwayjs/midway/compare/v2.3.4...v2.3.6) (2020-10-02)


### Bug Fixes

* implement optional dep for amqplib in mock package ([#654](https://github.com/midwayjs/midway/issues/654)) ([3319872](https://github.com/midwayjs/midway/commit/33198727855ff042db7d96723992b49c632aa25d))





## [2.3.2](https://github.com/midwayjs/midway/compare/v2.3.1...v2.3.2) (2020-09-28)

**Note:** Version bump only for package @midwayjs/bootstrap





## [2.3.1](https://github.com/midwayjs/midway/compare/v2.3.0...v2.3.1) (2020-09-27)

**Note:** Version bump only for package @midwayjs/bootstrap





# [2.3.0](https://github.com/midwayjs/midway/compare/v2.2.10...v2.3.0) (2020-09-27)


### Features

* add rabbitmq ([#647](https://github.com/midwayjs/midway/issues/647)) ([2c03eb4](https://github.com/midwayjs/midway/commit/2c03eb4f5e979d309048a11f17f7579a1d299ba1))





## [2.2.10](https://github.com/midwayjs/midway/compare/v2.2.9...v2.2.10) (2020-09-24)

**Note:** Version bump only for package @midwayjs/bootstrap





## [2.2.9](https://github.com/midwayjs/midway/compare/v2.2.8...v2.2.9) (2020-09-24)


### Bug Fixes

* remove sourcemap and src in dist ([#645](https://github.com/midwayjs/midway/issues/645)) ([e561a88](https://github.com/midwayjs/midway/commit/e561a88f4a70af15d4be3d5fe0bd39487677d4ce))





## [2.2.8](https://github.com/midwayjs/midway/compare/v2.2.7...v2.2.8) (2020-09-23)

**Note:** Version bump only for package @midwayjs/bootstrap





## [2.2.7](https://github.com/midwayjs/midway/compare/v2.2.6...v2.2.7) (2020-09-20)


### Bug Fixes

* WebMiddleare to IWebMiddleware ([e69cf28](https://github.com/midwayjs/midway/commit/e69cf286fa76ab3144404806c5cbbe8642cdcd61))





## [2.2.6](https://github.com/midwayjs/midway/compare/v2.2.5...v2.2.6) (2020-09-18)


### Features

* add aop ([#640](https://github.com/midwayjs/midway/issues/640)) ([c3e15b3](https://github.com/midwayjs/midway/commit/c3e15b328c184318e364bf40d32fa4df6be2a30a))





## [2.2.5](https://github.com/midwayjs/midway/compare/v2.2.4...v2.2.5) (2020-09-17)


### Features

* use midway cli replace egg-bin ([#639](https://github.com/midwayjs/midway/issues/639)) ([62bbf38](https://github.com/midwayjs/midway/commit/62bbf3852899476600a0b594cb7dc274b05e29ec))





## [2.2.4](https://github.com/midwayjs/midway/compare/v2.2.3...v2.2.4) (2020-09-15)

**Note:** Version bump only for package @midwayjs/bootstrap





## [2.2.3](https://github.com/midwayjs/midway/compare/v2.2.2...v2.2.3) (2020-09-14)

**Note:** Version bump only for package @midwayjs/bootstrap





## [2.2.2](https://github.com/midwayjs/midway/compare/v2.2.1...v2.2.2) (2020-09-14)

**Note:** Version bump only for package @midwayjs/bootstrap





## [2.2.1](https://github.com/midwayjs/midway/compare/v2.2.0...v2.2.1) (2020-09-14)

**Note:** Version bump only for package @midwayjs/bootstrap





# [2.2.0](https://github.com/midwayjs/midway/compare/v2.1.4...v2.2.0) (2020-09-13)


### Features

* complete 2.x beta ([#630](https://github.com/midwayjs/midway/issues/630)) ([b23cd00](https://github.com/midwayjs/midway/commit/b23cd00fe9cefc9057a2284d38d5419773539206))
