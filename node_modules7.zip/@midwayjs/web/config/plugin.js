'use strict';

module.exports = {
  static: false,
  development: false,
  watcher: false,
  schedulePlus: {
    enable: true,
    package: 'midway-schedule',
  },
  logrotator: false,
};
