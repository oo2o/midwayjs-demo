'use strict';

module.exports = {
  watcher: {
    enable: false,
  },
  development: {
    enable: false,
  },
};
