'use strict';

module.exports = require('../../dist/app/extend/application');
