'use strict';

// exports = require('./dist/bootstrap')

function __export(m) {
  // eslint-disable-next-line no-prototype-builtins
  for (const p in m) if (!exports.hasOwnProperty(p)) exports[p] = m[p];
}
Object.defineProperty(exports, '__esModule', { value: true });
__export(require('./dist/bootstrap'));
