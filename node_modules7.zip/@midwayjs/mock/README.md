# midway-mock

[![Package Quality](http://npm.packagequality.com/shield/midway-mock.svg)](http://packagequality.com/#?package=midway-mock)
[![PRs Welcome](https://img.shields.io/badge/PRs-welcome-brightgreen.svg)](https://github.com/midwayjs/midway/pulls)

this is a sub package for midway.

Document: [https://midwayjs.org/midway](https://midwayjs.org/midway)

## License

[MIT]((http://github.com/midwayjs/midway/blob/master/LICENSE))
