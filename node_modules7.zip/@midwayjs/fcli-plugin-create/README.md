# faas-cli create

`f create` command
