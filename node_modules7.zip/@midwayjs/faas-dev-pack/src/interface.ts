export interface InvokeParams {
  functionName: string;
  data?: any;
  contextData?: string;
  eventType?: string;
  verbose?: boolean;
}
