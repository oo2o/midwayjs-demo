# Change Log

All notable changes to this project will be documented in this file.
See [Conventional Commits](https://conventionalcommits.org) for commit guidelines.

## [1.2.37](https://github.com/midwayjs/cli/compare/v1.2.35...v1.2.37) (2021-01-08)


### Bug Fixes

* support package diagnostics & tsConfig config ([#38](https://github.com/midwayjs/cli/issues/38)) ([c499d14](https://github.com/midwayjs/cli/commit/c499d145f9cabf427877ec8ea65aea8ead42b9cd))





## [1.2.35](https://github.com/midwayjs/cli/compare/v1.2.33...v1.2.35) (2020-12-24)


### Bug Fixes

* copy file error catch ([8d2097c](https://github.com/midwayjs/cli/commit/8d2097c538f22ed6050c85d1c250436e0c2c71c1))





## [1.2.34](https://github.com/midwayjs/cli/compare/v1.2.34-beta.2...v1.2.34) (2020-12-20)

**Note:** Version bump only for package @midwayjs/fcli-plugin-invoke





## [1.2.33](https://github.com/midwayjs/cli/compare/v1.2.32...v1.2.33) (2020-12-17)

**Note:** Version bump only for package @midwayjs/fcli-plugin-invoke





## [1.2.32](https://github.com/midwayjs/cli/compare/v1.2.32-beta...v1.2.32) (2020-12-08)

**Note:** Version bump only for package @midwayjs/fcli-plugin-invoke





## [1.2.31](https://github.com/midwayjs/cli/compare/v1.2.30...v1.2.31) (2020-12-03)

**Note:** Version bump only for package @midwayjs/fcli-plugin-invoke





## [1.2.30](https://github.com/midwayjs/cli/compare/v1.2.30-beta...v1.2.30) (2020-11-30)

**Note:** Version bump only for package @midwayjs/fcli-plugin-invoke





## [1.2.29](https://github.com/midwayjs/cli/compare/serverless-v1.2.28...serverless-v1.2.29) (2020-11-18)


### Bug Fixes

* multi function invoke same time ([#26](https://github.com/midwayjs/cli/issues/26)) ([818ae86](https://github.com/midwayjs/cli/commit/818ae861d5e009396a60bee0d8bd0ef71093daa2))





## [1.2.28](https://github.com/midwayjs/midway-faas/compare/serverless-v1.2.27...serverless-v1.2.28) (2020-11-18)


### Bug Fixes

* invoke error ([#25](https://github.com/midwayjs/midway-faas/issues/25)) ([1a994b2](https://github.com/midwayjs/midway-faas/commit/1a994b2f0c6339786e856f7d4526b120cba627cf))





## [1.2.27](https://github.com/midwayjs/midway-faas/compare/serverless-v1.2.26...serverless-v1.2.27) (2020-11-17)

**Note:** Version bump only for package @midwayjs/fcli-plugin-invoke





## [1.2.26](https://github.com/midwayjs/midway-faas/compare/serverless-v1.2.21...serverless-v1.2.26) (2020-11-17)



## 1.2.25 (2020-11-12)



## 1.2.25-beta.1 (2020-11-12)



## 1.2.24-beta.1 (2020-11-12)


### Bug Fixes

* midway2 bootstrap ([#22](https://github.com/midwayjs/midway-faas/issues/22)) ([5673fc6](https://github.com/midwayjs/midway-faas/commit/5673fc6de1f384f88bd2376e51358d1570f06d43))



## 1.2.23 (2020-11-11)



## 1.2.23-beta.3 (2020-11-10)



## 1.2.23-beta.2 (2020-10-30)



## 1.2.23-beta.1 (2020-10-26)


### Bug Fixes

* dev pack start auto remove cache ([#17](https://github.com/midwayjs/midway-faas/issues/17)) ([c2c090b](https://github.com/midwayjs/midway-faas/commit/c2c090b4f6419ea6fe3cdde448e9ab07b795dfd2))
* fcli create ([#15](https://github.com/midwayjs/midway-faas/issues/15)) ([eb8a673](https://github.com/midwayjs/midway-faas/commit/eb8a67315cfecc8131d9947bf0e79fa71ec57e46))





## [1.2.25](https://github.com/midwayjs/midway-faas/compare/v1.2.25-beta.1...v1.2.25) (2020-11-12)

**Note:** Version bump only for package @midwayjs/fcli-plugin-invoke





## [1.2.25-beta.1](https://github.com/midwayjs/midway-faas/compare/v1.2.24-beta.1...v1.2.25-beta.1) (2020-11-12)

**Note:** Version bump only for package @midwayjs/fcli-plugin-invoke





## [1.2.24-beta.1](https://github.com/midwayjs/midway-faas/compare/v1.2.24...v1.2.24-beta.1) (2020-11-12)


### Bug Fixes

* midway2 bootstrap ([#22](https://github.com/midwayjs/midway-faas/issues/22)) ([5673fc6](https://github.com/midwayjs/midway-faas/commit/5673fc6de1f384f88bd2376e51358d1570f06d43))





## [1.2.23](https://github.com/midwayjs/midway-faas/compare/v1.2.23-beta.3...v1.2.23) (2020-11-11)

**Note:** Version bump only for package @midwayjs/fcli-plugin-invoke





## [1.2.23-beta.3](https://github.com/midwayjs/midway-faas/compare/v1.2.23-beta.2...v1.2.23-beta.3) (2020-11-10)

**Note:** Version bump only for package @midwayjs/fcli-plugin-invoke





## [1.2.23-beta.2](https://github.com/midwayjs/midway-faas/compare/v1.2.23-beta.1...v1.2.23-beta.2) (2020-10-30)

**Note:** Version bump only for package @midwayjs/fcli-plugin-invoke





## [1.2.23-beta.1](https://github.com/midwayjs/midway-faas/compare/v1.2.20...v1.2.23-beta.1) (2020-10-26)


### Bug Fixes

* dev pack start auto remove cache ([#17](https://github.com/midwayjs/midway-faas/issues/17)) ([c2c090b](https://github.com/midwayjs/midway-faas/commit/c2c090b4f6419ea6fe3cdde448e9ab07b795dfd2))
* fcli create ([#15](https://github.com/midwayjs/midway-faas/issues/15)) ([eb8a673](https://github.com/midwayjs/midway-faas/commit/eb8a67315cfecc8131d9947bf0e79fa71ec57e46))





## [1.2.22](https://github.com/midwayjs/midway-faas/compare/v1.2.22-beta.1...v1.2.22) (2020-10-21)

**Note:** Version bump only for package @midwayjs/fcli-plugin-invoke





## [1.2.22-beta.1](https://github.com/midwayjs/midway-faas/compare/v1.2.20...v1.2.22-beta.1) (2020-10-21)

**Note:** Version bump only for package @midwayjs/fcli-plugin-invoke





## [1.2.21](https://github.com/midwayjs/midway-faas/compare/serverless-v1.2.19...serverless-v1.2.21) (2020-10-20)



## 1.2.20 (2020-10-19)



## 1.2.20-beta.5 (2020-10-19)



## 1.2.20-beta.4 (2020-10-19)


### Bug Fixes

* starter-in-runtime-extension ([#13](https://github.com/midwayjs/midway-faas/issues/13)) ([8dd40c1](https://github.com/midwayjs/midway-faas/commit/8dd40c1ba4f1bbefe16863c7057c8ccfc8436b56))





## [1.2.20](https://github.com/midwayjs/midway-faas/compare/v1.2.20-beta.5...v1.2.20) (2020-10-19)

**Note:** Version bump only for package @midwayjs/fcli-plugin-invoke





## [1.2.20-beta.5](https://github.com/midwayjs/midway-faas/compare/v1.2.20-beta.4...v1.2.20-beta.5) (2020-10-19)

**Note:** Version bump only for package @midwayjs/fcli-plugin-invoke





## [1.2.20-beta.4](https://github.com/midwayjs/midway-faas/compare/v1.0.4...v1.2.20-beta.4) (2020-10-19)


### Bug Fixes

* starter-in-runtime-extension ([#13](https://github.com/midwayjs/midway-faas/issues/13)) ([8dd40c1](https://github.com/midwayjs/midway-faas/commit/8dd40c1ba4f1bbefe16863c7057c8ccfc8436b56))





## [1.2.20-beta.3](https://github.com/midwayjs/midway-faas/compare/v1.2.20-beta.2...v1.2.20-beta.3) (2020-10-19)

**Note:** Version bump only for package @midwayjs/fcli-plugin-invoke





## [1.2.20-beta.2](https://github.com/midwayjs/midway-faas/compare/v1.2.20-beta.1...v1.2.20-beta.2) (2020-10-19)

**Note:** Version bump only for package @midwayjs/fcli-plugin-invoke





## [1.2.20-beta.1](https://github.com/midwayjs/midway-faas/compare/v1.0.4...v1.2.20-beta.1) (2020-10-19)

**Note:** Version bump only for package @midwayjs/fcli-plugin-invoke





## [1.2.18](https://github.com/midwayjs/midway-faas/compare/serverless-v1.2.17...serverless-v1.2.18) (2020-09-23)

**Note:** Version bump only for package @midwayjs/fcli-plugin-invoke





## [1.2.17](https://github.com/midwayjs/midway-faas/compare/serverless-v1.2.16...serverless-v1.2.17) (2020-09-23)

**Note:** Version bump only for package @midwayjs/fcli-plugin-invoke





## [1.2.16](https://github.com/midwayjs/midway-faas/compare/serverless-v1.2.15...serverless-v1.2.16) (2020-09-22)

**Note:** Version bump only for package @midwayjs/fcli-plugin-invoke





## 1.2.15 (2020-09-22)

**Note:** Version bump only for package @midwayjs/fcli-plugin-invoke





## [1.2.12](https://github.com/midwayjs/midway-faas/compare/serverless-v1.2.11...serverless-v1.2.12) (2020-09-04)


### Bug Fixes

* support npm multi plugin ([#627](https://github.com/midwayjs/midway-faas/issues/627)) ([d2ebc2e](https://github.com/midwayjs/midway-faas/commit/d2ebc2ec70374db5f1ea595d7ccaacbe9ef540a4))





## [1.2.11](https://github.com/midwayjs/midway-faas/compare/serverless-v1.2.10...serverless-v1.2.11) (2020-09-04)

**Note:** Version bump only for package @midwayjs/fcli-plugin-invoke





## [1.2.10](https://github.com/midwayjs/midway-faas/compare/serverless-v1.2.9...serverless-v1.2.10) (2020-08-30)

**Note:** Version bump only for package @midwayjs/fcli-plugin-invoke





## [1.2.9](https://github.com/midwayjs/midway-faas/compare/serverless-v1.2.8...serverless-v1.2.9) (2020-08-26)

**Note:** Version bump only for package @midwayjs/fcli-plugin-invoke





## [1.2.8](https://github.com/midwayjs/midway-faas/compare/serverless-v1.2.7...serverless-v1.2.8) (2020-08-24)

**Note:** Version bump only for package @midwayjs/fcli-plugin-invoke





## [1.2.7](https://github.com/midwayjs/midway-faas/compare/serverless-v1.2.6...serverless-v1.2.7) (2020-08-21)

**Note:** Version bump only for package @midwayjs/fcli-plugin-invoke





## [1.2.6](https://github.com/midwayjs/midway-faas/compare/serverless-v1.2.5...serverless-v1.2.6) (2020-08-19)


### Bug Fixes

* static copy ([#613](https://github.com/midwayjs/midway-faas/issues/613)) ([c572b04](https://github.com/midwayjs/midway-faas/commit/c572b044a1411c641b40fb7ff0ed52a3f65df0ee))





## [1.2.5](https://github.com/midwayjs/midway-faas/compare/serverless-v1.2.4...serverless-v1.2.5) (2020-08-19)


### Bug Fixes

* invoke error output ([#610](https://github.com/midwayjs/midway-faas/issues/610)) ([9724f4a](https://github.com/midwayjs/midway-faas/commit/9724f4a06e301fe37e428b9428aa6d1639232301))





## [1.2.4](https://github.com/midwayjs/midway-faas/compare/serverless-v1.2.3...serverless-v1.2.4) (2020-08-19)


### Bug Fixes

* support static file copy ([#608](https://github.com/midwayjs/midway-faas/issues/608)) ([941bc5c](https://github.com/midwayjs/midway-faas/commit/941bc5c35d816e57f08d069e11818279ace475bd))





## [1.2.3](https://github.com/midwayjs/midway-faas/compare/serverless-v1.2.2...serverless-v1.2.3) (2020-08-18)

**Note:** Version bump only for package @midwayjs/fcli-plugin-invoke





## [1.2.2](https://github.com/midwayjs/midway-faas/compare/serverless-v1.2.1...serverless-v1.2.2) (2020-08-18)

**Note:** Version bump only for package @midwayjs/fcli-plugin-invoke





## [1.2.1](https://github.com/midwayjs/midway-faas/compare/serverless-v1.2.0...serverless-v1.2.1) (2020-08-17)

**Note:** Version bump only for package @midwayjs/fcli-plugin-invoke





## [1.2.1](https://github.com/midwayjs/midway-faas/compare/v1.1.4...v1.2.1) (2020-08-17)


### Bug Fixes

* clean temp directory in local env ([#597](https://github.com/midwayjs/midway-faas/issues/597)) ([798cdf1](https://github.com/midwayjs/midway-faas/commit/798cdf12be8c77d1bf33a575d4c6e4a82153d597))
* fp args ([#561](https://github.com/midwayjs/midway-faas/issues/561)) ([e91983e](https://github.com/midwayjs/midway-faas/commit/e91983e6ee1d9e725eaed061b80cde083bdf7e1d))
* register faas ctx ([#559](https://github.com/midwayjs/midway-faas/issues/559)) ([d9e1764](https://github.com/midwayjs/midway-faas/commit/d9e1764d55c053e74f9cad2b70641ba7b8ab70c3))
* use ts analyze cache ([#560](https://github.com/midwayjs/midway-faas/issues/560)) ([06dbcb5](https://github.com/midwayjs/midway-faas/commit/06dbcb52210f6a43ed8d54d5288b09c1243d0665))
* wrapper compare ([#553](https://github.com/midwayjs/midway-faas/issues/553)) ([426aa65](https://github.com/midwayjs/midway-faas/commit/426aa65f2eb0d9f4312f5375ea39f9186f2a083c))


### Features

* add hooks ([#601](https://github.com/midwayjs/midway-faas/issues/601)) ([e9973f1](https://github.com/midwayjs/midway-faas/commit/e9973f110e3654d619ff7bc4020608c2082e47ae))





# [1.2.0](https://github.com/midwayjs/midway-faas/compare/serverless-v1.1.21...serverless-v1.2.0) (2020-08-17)


### Features

* add hooks ([#601](https://github.com/midwayjs/midway-faas/issues/601)) ([e9973f1](https://github.com/midwayjs/midway-faas/commit/e9973f110e3654d619ff7bc4020608c2082e47ae))





## [1.1.21](https://github.com/midwayjs/midway-faas/compare/serverless-v1.1.20...serverless-v1.1.21) (2020-08-12)

**Note:** Version bump only for package @midwayjs/fcli-plugin-invoke





## [1.1.20](https://github.com/midwayjs/midway-faas/compare/serverless-v1.1.19...serverless-v1.1.20) (2020-08-12)


### Bug Fixes

* clean temp directory in local env ([#597](https://github.com/midwayjs/midway-faas/issues/597)) ([798cdf1](https://github.com/midwayjs/midway-faas/commit/798cdf12be8c77d1bf33a575d4c6e4a82153d597))





## [1.1.19](https://github.com/midwayjs/midway-faas/compare/serverless-v1.1.18...serverless-v1.1.19) (2020-08-11)

**Note:** Version bump only for package @midwayjs/fcli-plugin-invoke





## [1.1.18](https://github.com/midwayjs/midway-faas/compare/serverless-v1.1.17...serverless-v1.1.18) (2020-08-11)

**Note:** Version bump only for package @midwayjs/fcli-plugin-invoke





## [1.1.16](https://github.com/midwayjs/midway-faas/compare/serverless-v1.1.15...serverless-v1.1.16) (2020-08-05)

**Note:** Version bump only for package @midwayjs/fcli-plugin-invoke





## [1.1.15](https://github.com/midwayjs/midway-faas/compare/serverless-v1.1.14...serverless-v1.1.15) (2020-08-05)

**Note:** Version bump only for package @midwayjs/fcli-plugin-invoke





## [1.1.14](https://github.com/midwayjs/midway-faas/compare/serverless-v1.1.13...serverless-v1.1.14) (2020-08-04)

**Note:** Version bump only for package @midwayjs/fcli-plugin-invoke





## [1.1.13](https://github.com/midwayjs/midway-faas/compare/serverless-v1.1.12...serverless-v1.1.13) (2020-08-03)

**Note:** Version bump only for package @midwayjs/fcli-plugin-invoke





## [1.1.12](https://github.com/midwayjs/midway-faas/compare/serverless-v1.1.11...serverless-v1.1.12) (2020-07-29)

**Note:** Version bump only for package @midwayjs/fcli-plugin-invoke





## [1.1.10](https://github.com/midwayjs/midway-faas/compare/serverless-v1.1.9...serverless-v1.1.10) (2020-07-28)

**Note:** Version bump only for package @midwayjs/fcli-plugin-invoke





## [1.1.9](https://github.com/midwayjs/midway-faas/compare/v1.1.4...v1.1.9) (2020-07-28)


### Bug Fixes

* fp args ([#561](https://github.com/midwayjs/midway-faas/issues/561)) ([e91983e](https://github.com/midwayjs/midway-faas/commit/e91983e6ee1d9e725eaed061b80cde083bdf7e1d))
* register faas ctx ([#559](https://github.com/midwayjs/midway-faas/issues/559)) ([d9e1764](https://github.com/midwayjs/midway-faas/commit/d9e1764d55c053e74f9cad2b70641ba7b8ab70c3))
* use ts analyze cache ([#560](https://github.com/midwayjs/midway-faas/issues/560)) ([06dbcb5](https://github.com/midwayjs/midway-faas/commit/06dbcb52210f6a43ed8d54d5288b09c1243d0665))
* wrapper compare ([#553](https://github.com/midwayjs/midway-faas/issues/553)) ([426aa65](https://github.com/midwayjs/midway-faas/commit/426aa65f2eb0d9f4312f5375ea39f9186f2a083c))





## [1.1.8](https://github.com/midwayjs/midway-faas/compare/serverless-v1.1.7...serverless-v1.1.8) (2020-07-27)


### Bug Fixes

* fp args ([#561](https://github.com/midwayjs/midway-faas/issues/561)) ([e91983e](https://github.com/midwayjs/midway-faas/commit/e91983e6ee1d9e725eaed061b80cde083bdf7e1d))





## [1.1.7](https://github.com/midwayjs/midway-faas/compare/serverless-v1.1.6...serverless-v1.1.7) (2020-07-26)


### Bug Fixes

* use ts analyze cache ([#560](https://github.com/midwayjs/midway-faas/issues/560)) ([06dbcb5](https://github.com/midwayjs/midway-faas/commit/06dbcb52210f6a43ed8d54d5288b09c1243d0665))





## [1.1.6](https://github.com/midwayjs/midway-faas/compare/serverless-v1.1.5...serverless-v1.1.6) (2020-07-26)


### Bug Fixes

* register faas ctx ([#559](https://github.com/midwayjs/midway-faas/issues/559)) ([d9e1764](https://github.com/midwayjs/midway-faas/commit/d9e1764d55c053e74f9cad2b70641ba7b8ab70c3))





## [1.1.5](https://github.com/midwayjs/midway-faas/compare/serverless-v1.1.3...serverless-v1.1.5) (2020-07-24)


### Bug Fixes

* wrapper compare ([#553](https://github.com/midwayjs/midway-faas/issues/553)) ([426aa65](https://github.com/midwayjs/midway-faas/commit/426aa65f2eb0d9f4312f5375ea39f9186f2a083c))



## 1.1.4 (2020-07-24)





## [1.1.4](https://github.com/midwayjs/midway-faas/compare/v1.0.8...v1.1.4) (2020-07-24)


### Bug Fixes

* add analysisCode lifecycle ([#535](https://github.com/midwayjs/midway-faas/issues/535)) ([1bf2e8a](https://github.com/midwayjs/midway-faas/commit/1bf2e8a65b658b3c5a341245e02a97b9d96eb856))
* ts-mode ([#552](https://github.com/midwayjs/midway-faas/issues/552)) ([d8f231c](https://github.com/midwayjs/midway-faas/commit/d8f231c8a0ad5c50d42809e915c1669b67902305))


### Features

* mwcc multi stage compilation support ([#523](https://github.com/midwayjs/midway-faas/issues/523)) ([c5a64f2](https://github.com/midwayjs/midway-faas/commit/c5a64f216aeddda4c62d4ae674ed4eb27433e751))
* progressive ([#551](https://github.com/midwayjs/midway-faas/issues/551)) ([7b0060e](https://github.com/midwayjs/midway-faas/commit/7b0060e642de8e62ee07d9f4ca8c9aa569f3f34f))





## [1.1.3](https://github.com/midwayjs/midway-faas/compare/serverless-v1.1.2...serverless-v1.1.3) (2020-07-24)


### Bug Fixes

* ts-mode ([#552](https://github.com/midwayjs/midway-faas/issues/552)) ([d8f231c](https://github.com/midwayjs/midway-faas/commit/d8f231c8a0ad5c50d42809e915c1669b67902305))


### Features

* progressive ([#551](https://github.com/midwayjs/midway-faas/issues/551)) ([7b0060e](https://github.com/midwayjs/midway-faas/commit/7b0060e642de8e62ee07d9f4ca8c9aa569f3f34f))





## [1.1.2](https://github.com/midwayjs/midway-faas/compare/serverless-v1.1.1...serverless-v1.1.2) (2020-07-23)

**Note:** Version bump only for package @midwayjs/fcli-plugin-invoke





## [1.1.1](https://github.com/midwayjs/midway-faas/compare/serverless-v1.1.0...serverless-v1.1.1) (2020-07-22)

**Note:** Version bump only for package @midwayjs/fcli-plugin-invoke





# [1.1.0](https://github.com/midwayjs/midway-faas/compare/serverless-v1.0.11...serverless-v1.1.0) (2020-07-21)

**Note:** Version bump only for package @midwayjs/fcli-plugin-invoke





## [1.0.11](https://github.com/midwayjs/midway-faas/compare/serverless-v1.0.10...serverless-v1.0.11) (2020-07-21)


### Bug Fixes

* add analysisCode lifecycle ([#535](https://github.com/midwayjs/midway-faas/issues/535)) ([1bf2e8a](https://github.com/midwayjs/midway-faas/commit/1bf2e8a65b658b3c5a341245e02a97b9d96eb856))





## [1.0.10](https://github.com/midwayjs/midway-faas/compare/serverless-v1.0.9...serverless-v1.0.10) (2020-07-16)


### Features

* mwcc multi stage compilation support ([#523](https://github.com/midwayjs/midway-faas/issues/523)) ([c5a64f2](https://github.com/midwayjs/midway-faas/commit/c5a64f216aeddda4c62d4ae674ed4eb27433e751))





## [1.0.8](https://github.com/midwayjs/midway-faas/compare/v1.0.7...v1.0.8) (2020-07-14)

**Note:** Version bump only for package @midwayjs/fcli-plugin-invoke





## 1.0.7 (2020-07-14)


### Bug Fixes

* code ana package ([#108](https://github.com/midwayjs/midway-faas/issues/108)) ([6e11d0f](https://github.com/midwayjs/midway-faas/commit/6e11d0f588e10b41551256a23a7d4fd6b8133c93))
* core hooks ([#104](https://github.com/midwayjs/midway-faas/issues/104)) ([ac6b574](https://github.com/midwayjs/midway-faas/commit/ac6b574b7bab95358d5f14214711390959ad56b6))
* core support stop ([#111](https://github.com/midwayjs/midway-faas/issues/111)) ([4ecf423](https://github.com/midwayjs/midway-faas/commit/4ecf423dc2b0366b90b2d40b39a229421d4ee006)), closes [#107](https://github.com/midwayjs/midway-faas/issues/107)
* dev pack clean ([#141](https://github.com/midwayjs/midway-faas/issues/141)) ([d2731c8](https://github.com/midwayjs/midway-faas/commit/d2731c8bf8c662e06131eec80bdbc20474e39d89))
* entry ([#154](https://github.com/midwayjs/midway-faas/issues/154)) ([c3c745d](https://github.com/midwayjs/midway-faas/commit/c3c745de7716245656d4eb156e55bd79c7177e64))
* file compare & npm options ([#62](https://github.com/midwayjs/midway-faas/issues/62)) ([beb50f8](https://github.com/midwayjs/midway-faas/commit/beb50f85106cd627aac7b2ab0317ed29ae830e33))
* fix error control in fc ([#153](https://github.com/midwayjs/midway-faas/issues/153)) ([f7dd007](https://github.com/midwayjs/midway-faas/commit/f7dd0070f9c1b7f07e628c8d2052d273a8133910))
* fix windows path when invoke ([#169](https://github.com/midwayjs/midway-faas/issues/169)) ([e637a0a](https://github.com/midwayjs/midway-faas/commit/e637a0ab05a769a3797e2dccf0612bbbf650d074))
* invoke bug ([#106](https://github.com/midwayjs/midway-faas/issues/106)) ([d45ff3f](https://github.com/midwayjs/midway-faas/commit/d45ff3f3c41764d08c6968dbdd676d174b695d96))
* invoke bug ([#110](https://github.com/midwayjs/midway-faas/issues/110)) ([7c2d000](https://github.com/midwayjs/midway-faas/commit/7c2d000404cb185ff8597e9b3acea2a0955f1bda))
* invoke getFuncList and core auto load plugin ([#112](https://github.com/midwayjs/midway-faas/issues/112)) ([54e4d11](https://github.com/midwayjs/midway-faas/commit/54e4d1151942075b86d187c46fc107b9ff1d816b))
* invoke hooks ([#113](https://github.com/midwayjs/midway-faas/issues/113)) ([765ec7e](https://github.com/midwayjs/midway-faas/commit/765ec7e259775360ff0c26755bdf78843b3658bf))
* invoke missing cwd ([#116](https://github.com/midwayjs/midway-faas/issues/116)) ([424e08b](https://github.com/midwayjs/midway-faas/commit/424e08bf63e8ce31d8f50b234d3c6beb00a05c9a))
* invoke source map ([#52](https://github.com/midwayjs/midway-faas/issues/52)) ([9149d2a](https://github.com/midwayjs/midway-faas/commit/9149d2a9a3f3d9ba975588b61c6f9bbeec2e8d86)), closes [#51](https://github.com/midwayjs/midway-faas/issues/51)
* load spec ([#119](https://github.com/midwayjs/midway-faas/issues/119)) ([66df38c](https://github.com/midwayjs/midway-faas/commit/66df38c221c033cf1ba9e28fcdc9953e33aabf34))
* refactor appregation & pass process env to invoke debug ([#24](https://github.com/midwayjs/midway-faas/issues/24)) ([f8cd981](https://github.com/midwayjs/midway-faas/commit/f8cd98118e91d3e1b15c2b37d1aaad6b15282f26))
* Refactor/invoke ([#178](https://github.com/midwayjs/midway-faas/issues/178)) ([37dd34f](https://github.com/midwayjs/midway-faas/commit/37dd34feab822900af61d7515bc0a4cbed7b20f8))
* serverless invoke ([#117](https://github.com/midwayjs/midway-faas/issues/117)) ([e6e37af](https://github.com/midwayjs/midway-faas/commit/e6e37af83856292d8e54896a0c3543cc50aba86e))
* support apigw ([2321c08](https://github.com/midwayjs/midway-faas/commit/2321c08be4ed7a076aa6004df95a64f04db0ee6d))
* support typescript run ([#139](https://github.com/midwayjs/midway-faas/issues/139)) ([472c985](https://github.com/midwayjs/midway-faas/commit/472c985d054f452ed79b496d348a95adc754663e))
* tencent trigger ([#131](https://github.com/midwayjs/midway-faas/issues/131)) ([0e93057](https://github.com/midwayjs/midway-faas/commit/0e93057205c2b761d1ee6fcf7e9c5d35bab349a7))
* ts load dir ([#140](https://github.com/midwayjs/midway-faas/issues/140)) ([354c08c](https://github.com/midwayjs/midway-faas/commit/354c08cd6f7d50918f2393b8dddb90857735d5ac))


### Features

* add dev pack ([#134](https://github.com/midwayjs/midway-faas/issues/134)) ([cd08f54](https://github.com/midwayjs/midway-faas/commit/cd08f54859da80f517cb37f99857679286f10f0f))
* aws support ([#526](https://github.com/midwayjs/midway-faas/issues/526)) ([9da022e](https://github.com/midwayjs/midway-faas/commit/9da022ecdf1e7770c21705131679940adc67ff3c))
* command core store ([#72](https://github.com/midwayjs/midway-faas/issues/72)) ([10e68a9](https://github.com/midwayjs/midway-faas/commit/10e68a9a1cf096628eabb7b2b3f2c34dbdd14f3a))
* introduce `experimentalFeatures` root option ([#123](https://github.com/midwayjs/midway-faas/issues/123)) ([e20417f](https://github.com/midwayjs/midway-faas/commit/e20417f11e8bcdada52ca9835adeec6c16b67c06))
* introduce mwcc integration ([#103](https://github.com/midwayjs/midway-faas/issues/103)) ([40f458c](https://github.com/midwayjs/midway-faas/commit/40f458cf2c10903c03a93362cd691c04d97f91cd))
* new invoke ([#101](https://github.com/midwayjs/midway-faas/issues/101)) ([4c13a69](https://github.com/midwayjs/midway-faas/commit/4c13a695d9443f0f6683cad28967157f0d2ab496))
* single process invoke and debug ([#16](https://github.com/midwayjs/midway-faas/issues/16)) ([826a8c7](https://github.com/midwayjs/midway-faas/commit/826a8c7a7a36d8ec03a84f3d29498bef58811146))
* support debug by MIDWAY_FAAS_DEBUG ([#165](https://github.com/midwayjs/midway-faas/issues/165)) ([7c5cfc0](https://github.com/midwayjs/midway-faas/commit/7c5cfc0720fd3a6a58f4e30a477aa6500338f9b7))
* support url change ([#175](https://github.com/midwayjs/midway-faas/issues/175)) ([a2246b4](https://github.com/midwayjs/midway-faas/commit/a2246b4d792833be90314dcadf5af32d339e4e82))





## [1.0.6](https://github.com/midwayjs/midway-faas/compare/serverless-v1.0.5...serverless-v1.0.6) (2020-07-13)

**Note:** Version bump only for package @midwayjs/fcli-plugin-invoke





## [1.0.5](https://github.com/midwayjs/midway-faas/compare/serverless-v1.0.4...serverless-v1.0.5) (2020-07-10)

**Note:** Version bump only for package @midwayjs/fcli-plugin-invoke





## [1.0.4](https://github.com/midwayjs/midway-faas/compare/serverless-v1.0.3...serverless-v1.0.4) (2020-07-08)

**Note:** Version bump only for package @midwayjs/fcli-plugin-invoke





## [1.0.3](https://github.com/midwayjs/midway-faas/compare/serverless-v1.0.2...serverless-v1.0.3) (2020-07-07)

**Note:** Version bump only for package @midwayjs/fcli-plugin-invoke





## 1.0.2 (2020-07-06)


### Bug Fixes

* code ana package ([#108](https://github.com/midwayjs/midway-faas/issues/108)) ([6e11d0f](https://github.com/midwayjs/midway-faas/commit/6e11d0f588e10b41551256a23a7d4fd6b8133c93))
* core hooks ([#104](https://github.com/midwayjs/midway-faas/issues/104)) ([ac6b574](https://github.com/midwayjs/midway-faas/commit/ac6b574b7bab95358d5f14214711390959ad56b6))
* core support stop ([#111](https://github.com/midwayjs/midway-faas/issues/111)) ([4ecf423](https://github.com/midwayjs/midway-faas/commit/4ecf423dc2b0366b90b2d40b39a229421d4ee006)), closes [#107](https://github.com/midwayjs/midway-faas/issues/107)
* dev pack clean ([#141](https://github.com/midwayjs/midway-faas/issues/141)) ([d2731c8](https://github.com/midwayjs/midway-faas/commit/d2731c8bf8c662e06131eec80bdbc20474e39d89))
* entry ([#154](https://github.com/midwayjs/midway-faas/issues/154)) ([c3c745d](https://github.com/midwayjs/midway-faas/commit/c3c745de7716245656d4eb156e55bd79c7177e64))
* file compare & npm options ([#62](https://github.com/midwayjs/midway-faas/issues/62)) ([beb50f8](https://github.com/midwayjs/midway-faas/commit/beb50f85106cd627aac7b2ab0317ed29ae830e33))
* fix error control in fc ([#153](https://github.com/midwayjs/midway-faas/issues/153)) ([f7dd007](https://github.com/midwayjs/midway-faas/commit/f7dd0070f9c1b7f07e628c8d2052d273a8133910))
* fix windows path when invoke ([#169](https://github.com/midwayjs/midway-faas/issues/169)) ([e637a0a](https://github.com/midwayjs/midway-faas/commit/e637a0ab05a769a3797e2dccf0612bbbf650d074))
* invoke bug ([#106](https://github.com/midwayjs/midway-faas/issues/106)) ([d45ff3f](https://github.com/midwayjs/midway-faas/commit/d45ff3f3c41764d08c6968dbdd676d174b695d96))
* invoke bug ([#110](https://github.com/midwayjs/midway-faas/issues/110)) ([7c2d000](https://github.com/midwayjs/midway-faas/commit/7c2d000404cb185ff8597e9b3acea2a0955f1bda))
* invoke getFuncList and core auto load plugin ([#112](https://github.com/midwayjs/midway-faas/issues/112)) ([54e4d11](https://github.com/midwayjs/midway-faas/commit/54e4d1151942075b86d187c46fc107b9ff1d816b))
* invoke hooks ([#113](https://github.com/midwayjs/midway-faas/issues/113)) ([765ec7e](https://github.com/midwayjs/midway-faas/commit/765ec7e259775360ff0c26755bdf78843b3658bf))
* invoke missing cwd ([#116](https://github.com/midwayjs/midway-faas/issues/116)) ([424e08b](https://github.com/midwayjs/midway-faas/commit/424e08bf63e8ce31d8f50b234d3c6beb00a05c9a))
* invoke source map ([#52](https://github.com/midwayjs/midway-faas/issues/52)) ([9149d2a](https://github.com/midwayjs/midway-faas/commit/9149d2a9a3f3d9ba975588b61c6f9bbeec2e8d86)), closes [#51](https://github.com/midwayjs/midway-faas/issues/51)
* load spec ([#119](https://github.com/midwayjs/midway-faas/issues/119)) ([66df38c](https://github.com/midwayjs/midway-faas/commit/66df38c221c033cf1ba9e28fcdc9953e33aabf34))
* refactor appregation & pass process env to invoke debug ([#24](https://github.com/midwayjs/midway-faas/issues/24)) ([f8cd981](https://github.com/midwayjs/midway-faas/commit/f8cd98118e91d3e1b15c2b37d1aaad6b15282f26))
* Refactor/invoke ([#178](https://github.com/midwayjs/midway-faas/issues/178)) ([37dd34f](https://github.com/midwayjs/midway-faas/commit/37dd34feab822900af61d7515bc0a4cbed7b20f8))
* serverless invoke ([#117](https://github.com/midwayjs/midway-faas/issues/117)) ([e6e37af](https://github.com/midwayjs/midway-faas/commit/e6e37af83856292d8e54896a0c3543cc50aba86e))
* support apigw ([2321c08](https://github.com/midwayjs/midway-faas/commit/2321c08be4ed7a076aa6004df95a64f04db0ee6d))
* support typescript run ([#139](https://github.com/midwayjs/midway-faas/issues/139)) ([472c985](https://github.com/midwayjs/midway-faas/commit/472c985d054f452ed79b496d348a95adc754663e))
* tencent trigger ([#131](https://github.com/midwayjs/midway-faas/issues/131)) ([0e93057](https://github.com/midwayjs/midway-faas/commit/0e93057205c2b761d1ee6fcf7e9c5d35bab349a7))
* ts load dir ([#140](https://github.com/midwayjs/midway-faas/issues/140)) ([354c08c](https://github.com/midwayjs/midway-faas/commit/354c08cd6f7d50918f2393b8dddb90857735d5ac))


### Features

* add dev pack ([#134](https://github.com/midwayjs/midway-faas/issues/134)) ([cd08f54](https://github.com/midwayjs/midway-faas/commit/cd08f54859da80f517cb37f99857679286f10f0f))
* command core store ([#72](https://github.com/midwayjs/midway-faas/issues/72)) ([10e68a9](https://github.com/midwayjs/midway-faas/commit/10e68a9a1cf096628eabb7b2b3f2c34dbdd14f3a))
* introduce `experimentalFeatures` root option ([#123](https://github.com/midwayjs/midway-faas/issues/123)) ([e20417f](https://github.com/midwayjs/midway-faas/commit/e20417f11e8bcdada52ca9835adeec6c16b67c06))
* introduce mwcc integration ([#103](https://github.com/midwayjs/midway-faas/issues/103)) ([40f458c](https://github.com/midwayjs/midway-faas/commit/40f458cf2c10903c03a93362cd691c04d97f91cd))
* new invoke ([#101](https://github.com/midwayjs/midway-faas/issues/101)) ([4c13a69](https://github.com/midwayjs/midway-faas/commit/4c13a695d9443f0f6683cad28967157f0d2ab496))
* single process invoke and debug ([#16](https://github.com/midwayjs/midway-faas/issues/16)) ([826a8c7](https://github.com/midwayjs/midway-faas/commit/826a8c7a7a36d8ec03a84f3d29498bef58811146))
* support debug by MIDWAY_FAAS_DEBUG ([#165](https://github.com/midwayjs/midway-faas/issues/165)) ([7c5cfc0](https://github.com/midwayjs/midway-faas/commit/7c5cfc0720fd3a6a58f4e30a477aa6500338f9b7))
* support url change ([#175](https://github.com/midwayjs/midway-faas/issues/175)) ([a2246b4](https://github.com/midwayjs/midway-faas/commit/a2246b4d792833be90314dcadf5af32d339e4e82))





## 1.0.1 (2020-07-06)


### Bug Fixes

* code ana package ([#108](https://github.com/midwayjs/midway-faas/issues/108)) ([6e11d0f](https://github.com/midwayjs/midway-faas/commit/6e11d0f588e10b41551256a23a7d4fd6b8133c93))
* core hooks ([#104](https://github.com/midwayjs/midway-faas/issues/104)) ([ac6b574](https://github.com/midwayjs/midway-faas/commit/ac6b574b7bab95358d5f14214711390959ad56b6))
* core support stop ([#111](https://github.com/midwayjs/midway-faas/issues/111)) ([4ecf423](https://github.com/midwayjs/midway-faas/commit/4ecf423dc2b0366b90b2d40b39a229421d4ee006)), closes [#107](https://github.com/midwayjs/midway-faas/issues/107)
* dev pack clean ([#141](https://github.com/midwayjs/midway-faas/issues/141)) ([d2731c8](https://github.com/midwayjs/midway-faas/commit/d2731c8bf8c662e06131eec80bdbc20474e39d89))
* entry ([#154](https://github.com/midwayjs/midway-faas/issues/154)) ([c3c745d](https://github.com/midwayjs/midway-faas/commit/c3c745de7716245656d4eb156e55bd79c7177e64))
* file compare & npm options ([#62](https://github.com/midwayjs/midway-faas/issues/62)) ([beb50f8](https://github.com/midwayjs/midway-faas/commit/beb50f85106cd627aac7b2ab0317ed29ae830e33))
* fix error control in fc ([#153](https://github.com/midwayjs/midway-faas/issues/153)) ([f7dd007](https://github.com/midwayjs/midway-faas/commit/f7dd0070f9c1b7f07e628c8d2052d273a8133910))
* fix windows path when invoke ([#169](https://github.com/midwayjs/midway-faas/issues/169)) ([e637a0a](https://github.com/midwayjs/midway-faas/commit/e637a0ab05a769a3797e2dccf0612bbbf650d074))
* invoke bug ([#106](https://github.com/midwayjs/midway-faas/issues/106)) ([d45ff3f](https://github.com/midwayjs/midway-faas/commit/d45ff3f3c41764d08c6968dbdd676d174b695d96))
* invoke bug ([#110](https://github.com/midwayjs/midway-faas/issues/110)) ([7c2d000](https://github.com/midwayjs/midway-faas/commit/7c2d000404cb185ff8597e9b3acea2a0955f1bda))
* invoke getFuncList and core auto load plugin ([#112](https://github.com/midwayjs/midway-faas/issues/112)) ([54e4d11](https://github.com/midwayjs/midway-faas/commit/54e4d1151942075b86d187c46fc107b9ff1d816b))
* invoke hooks ([#113](https://github.com/midwayjs/midway-faas/issues/113)) ([765ec7e](https://github.com/midwayjs/midway-faas/commit/765ec7e259775360ff0c26755bdf78843b3658bf))
* invoke missing cwd ([#116](https://github.com/midwayjs/midway-faas/issues/116)) ([424e08b](https://github.com/midwayjs/midway-faas/commit/424e08bf63e8ce31d8f50b234d3c6beb00a05c9a))
* invoke source map ([#52](https://github.com/midwayjs/midway-faas/issues/52)) ([9149d2a](https://github.com/midwayjs/midway-faas/commit/9149d2a9a3f3d9ba975588b61c6f9bbeec2e8d86)), closes [#51](https://github.com/midwayjs/midway-faas/issues/51)
* load spec ([#119](https://github.com/midwayjs/midway-faas/issues/119)) ([66df38c](https://github.com/midwayjs/midway-faas/commit/66df38c221c033cf1ba9e28fcdc9953e33aabf34))
* refactor appregation & pass process env to invoke debug ([#24](https://github.com/midwayjs/midway-faas/issues/24)) ([f8cd981](https://github.com/midwayjs/midway-faas/commit/f8cd98118e91d3e1b15c2b37d1aaad6b15282f26))
* Refactor/invoke ([#178](https://github.com/midwayjs/midway-faas/issues/178)) ([37dd34f](https://github.com/midwayjs/midway-faas/commit/37dd34feab822900af61d7515bc0a4cbed7b20f8))
* serverless invoke ([#117](https://github.com/midwayjs/midway-faas/issues/117)) ([e6e37af](https://github.com/midwayjs/midway-faas/commit/e6e37af83856292d8e54896a0c3543cc50aba86e))
* support apigw ([2321c08](https://github.com/midwayjs/midway-faas/commit/2321c08be4ed7a076aa6004df95a64f04db0ee6d))
* support typescript run ([#139](https://github.com/midwayjs/midway-faas/issues/139)) ([472c985](https://github.com/midwayjs/midway-faas/commit/472c985d054f452ed79b496d348a95adc754663e))
* tencent trigger ([#131](https://github.com/midwayjs/midway-faas/issues/131)) ([0e93057](https://github.com/midwayjs/midway-faas/commit/0e93057205c2b761d1ee6fcf7e9c5d35bab349a7))
* ts load dir ([#140](https://github.com/midwayjs/midway-faas/issues/140)) ([354c08c](https://github.com/midwayjs/midway-faas/commit/354c08cd6f7d50918f2393b8dddb90857735d5ac))


### Features

* add dev pack ([#134](https://github.com/midwayjs/midway-faas/issues/134)) ([cd08f54](https://github.com/midwayjs/midway-faas/commit/cd08f54859da80f517cb37f99857679286f10f0f))
* command core store ([#72](https://github.com/midwayjs/midway-faas/issues/72)) ([10e68a9](https://github.com/midwayjs/midway-faas/commit/10e68a9a1cf096628eabb7b2b3f2c34dbdd14f3a))
* introduce `experimentalFeatures` root option ([#123](https://github.com/midwayjs/midway-faas/issues/123)) ([e20417f](https://github.com/midwayjs/midway-faas/commit/e20417f11e8bcdada52ca9835adeec6c16b67c06))
* introduce mwcc integration ([#103](https://github.com/midwayjs/midway-faas/issues/103)) ([40f458c](https://github.com/midwayjs/midway-faas/commit/40f458cf2c10903c03a93362cd691c04d97f91cd))
* new invoke ([#101](https://github.com/midwayjs/midway-faas/issues/101)) ([4c13a69](https://github.com/midwayjs/midway-faas/commit/4c13a695d9443f0f6683cad28967157f0d2ab496))
* single process invoke and debug ([#16](https://github.com/midwayjs/midway-faas/issues/16)) ([826a8c7](https://github.com/midwayjs/midway-faas/commit/826a8c7a7a36d8ec03a84f3d29498bef58811146))
* support debug by MIDWAY_FAAS_DEBUG ([#165](https://github.com/midwayjs/midway-faas/issues/165)) ([7c5cfc0](https://github.com/midwayjs/midway-faas/commit/7c5cfc0720fd3a6a58f4e30a477aa6500338f9b7))
* support url change ([#175](https://github.com/midwayjs/midway-faas/issues/175)) ([a2246b4](https://github.com/midwayjs/midway-faas/commit/a2246b4d792833be90314dcadf5af32d339e4e82))





# 1.0.0 (2020-07-02)


### Bug Fixes

* code ana package ([#108](https://github.com/midwayjs/midway-faas/issues/108)) ([6e11d0f](https://github.com/midwayjs/midway-faas/commit/6e11d0f588e10b41551256a23a7d4fd6b8133c93))
* core hooks ([#104](https://github.com/midwayjs/midway-faas/issues/104)) ([ac6b574](https://github.com/midwayjs/midway-faas/commit/ac6b574b7bab95358d5f14214711390959ad56b6))
* core support stop ([#111](https://github.com/midwayjs/midway-faas/issues/111)) ([4ecf423](https://github.com/midwayjs/midway-faas/commit/4ecf423dc2b0366b90b2d40b39a229421d4ee006)), closes [#107](https://github.com/midwayjs/midway-faas/issues/107)
* dev pack clean ([#141](https://github.com/midwayjs/midway-faas/issues/141)) ([d2731c8](https://github.com/midwayjs/midway-faas/commit/d2731c8bf8c662e06131eec80bdbc20474e39d89))
* entry ([#154](https://github.com/midwayjs/midway-faas/issues/154)) ([c3c745d](https://github.com/midwayjs/midway-faas/commit/c3c745de7716245656d4eb156e55bd79c7177e64))
* file compare & npm options ([#62](https://github.com/midwayjs/midway-faas/issues/62)) ([beb50f8](https://github.com/midwayjs/midway-faas/commit/beb50f85106cd627aac7b2ab0317ed29ae830e33))
* fix error control in fc ([#153](https://github.com/midwayjs/midway-faas/issues/153)) ([f7dd007](https://github.com/midwayjs/midway-faas/commit/f7dd0070f9c1b7f07e628c8d2052d273a8133910))
* fix windows path when invoke ([#169](https://github.com/midwayjs/midway-faas/issues/169)) ([e637a0a](https://github.com/midwayjs/midway-faas/commit/e637a0ab05a769a3797e2dccf0612bbbf650d074))
* invoke bug ([#106](https://github.com/midwayjs/midway-faas/issues/106)) ([d45ff3f](https://github.com/midwayjs/midway-faas/commit/d45ff3f3c41764d08c6968dbdd676d174b695d96))
* invoke bug ([#110](https://github.com/midwayjs/midway-faas/issues/110)) ([7c2d000](https://github.com/midwayjs/midway-faas/commit/7c2d000404cb185ff8597e9b3acea2a0955f1bda))
* invoke getFuncList and core auto load plugin ([#112](https://github.com/midwayjs/midway-faas/issues/112)) ([54e4d11](https://github.com/midwayjs/midway-faas/commit/54e4d1151942075b86d187c46fc107b9ff1d816b))
* invoke hooks ([#113](https://github.com/midwayjs/midway-faas/issues/113)) ([765ec7e](https://github.com/midwayjs/midway-faas/commit/765ec7e259775360ff0c26755bdf78843b3658bf))
* invoke missing cwd ([#116](https://github.com/midwayjs/midway-faas/issues/116)) ([424e08b](https://github.com/midwayjs/midway-faas/commit/424e08bf63e8ce31d8f50b234d3c6beb00a05c9a))
* invoke source map ([#52](https://github.com/midwayjs/midway-faas/issues/52)) ([9149d2a](https://github.com/midwayjs/midway-faas/commit/9149d2a9a3f3d9ba975588b61c6f9bbeec2e8d86)), closes [#51](https://github.com/midwayjs/midway-faas/issues/51)
* load spec ([#119](https://github.com/midwayjs/midway-faas/issues/119)) ([66df38c](https://github.com/midwayjs/midway-faas/commit/66df38c221c033cf1ba9e28fcdc9953e33aabf34))
* refactor appregation & pass process env to invoke debug ([#24](https://github.com/midwayjs/midway-faas/issues/24)) ([f8cd981](https://github.com/midwayjs/midway-faas/commit/f8cd98118e91d3e1b15c2b37d1aaad6b15282f26))
* Refactor/invoke ([#178](https://github.com/midwayjs/midway-faas/issues/178)) ([37dd34f](https://github.com/midwayjs/midway-faas/commit/37dd34feab822900af61d7515bc0a4cbed7b20f8))
* serverless invoke ([#117](https://github.com/midwayjs/midway-faas/issues/117)) ([e6e37af](https://github.com/midwayjs/midway-faas/commit/e6e37af83856292d8e54896a0c3543cc50aba86e))
* support apigw ([2321c08](https://github.com/midwayjs/midway-faas/commit/2321c08be4ed7a076aa6004df95a64f04db0ee6d))
* support typescript run ([#139](https://github.com/midwayjs/midway-faas/issues/139)) ([472c985](https://github.com/midwayjs/midway-faas/commit/472c985d054f452ed79b496d348a95adc754663e))
* tencent trigger ([#131](https://github.com/midwayjs/midway-faas/issues/131)) ([0e93057](https://github.com/midwayjs/midway-faas/commit/0e93057205c2b761d1ee6fcf7e9c5d35bab349a7))
* ts load dir ([#140](https://github.com/midwayjs/midway-faas/issues/140)) ([354c08c](https://github.com/midwayjs/midway-faas/commit/354c08cd6f7d50918f2393b8dddb90857735d5ac))


### Features

* add dev pack ([#134](https://github.com/midwayjs/midway-faas/issues/134)) ([cd08f54](https://github.com/midwayjs/midway-faas/commit/cd08f54859da80f517cb37f99857679286f10f0f))
* command core store ([#72](https://github.com/midwayjs/midway-faas/issues/72)) ([10e68a9](https://github.com/midwayjs/midway-faas/commit/10e68a9a1cf096628eabb7b2b3f2c34dbdd14f3a))
* introduce `experimentalFeatures` root option ([#123](https://github.com/midwayjs/midway-faas/issues/123)) ([e20417f](https://github.com/midwayjs/midway-faas/commit/e20417f11e8bcdada52ca9835adeec6c16b67c06))
* introduce mwcc integration ([#103](https://github.com/midwayjs/midway-faas/issues/103)) ([40f458c](https://github.com/midwayjs/midway-faas/commit/40f458cf2c10903c03a93362cd691c04d97f91cd))
* new invoke ([#101](https://github.com/midwayjs/midway-faas/issues/101)) ([4c13a69](https://github.com/midwayjs/midway-faas/commit/4c13a695d9443f0f6683cad28967157f0d2ab496))
* single process invoke and debug ([#16](https://github.com/midwayjs/midway-faas/issues/16)) ([826a8c7](https://github.com/midwayjs/midway-faas/commit/826a8c7a7a36d8ec03a84f3d29498bef58811146))
* support debug by MIDWAY_FAAS_DEBUG ([#165](https://github.com/midwayjs/midway-faas/issues/165)) ([7c5cfc0](https://github.com/midwayjs/midway-faas/commit/7c5cfc0720fd3a6a58f4e30a477aa6500338f9b7))
* support url change ([#175](https://github.com/midwayjs/midway-faas/issues/175)) ([a2246b4](https://github.com/midwayjs/midway-faas/commit/a2246b4d792833be90314dcadf5af32d339e4e82))





## [0.3.7](https://github.com/midwayjs/midway-faas/compare/v0.3.6...v0.3.7) (2020-07-02)

**Note:** Version bump only for package @midwayjs/fcli-plugin-invoke





## [0.3.6](https://github.com/midwayjs/midway-faas/compare/v0.3.5...v0.3.6) (2020-06-30)

**Note:** Version bump only for package @midwayjs/fcli-plugin-invoke





## [0.3.5](https://github.com/midwayjs/midway-faas/compare/v0.3.4...v0.3.5) (2020-06-28)

**Note:** Version bump only for package @midwayjs/fcli-plugin-invoke





## [0.3.3](https://github.com/midwayjs/midway-faas/compare/v0.3.2...v0.3.3) (2020-06-16)


### Bug Fixes

* Refactor/invoke ([#178](https://github.com/midwayjs/midway-faas/issues/178)) ([37dd34f](https://github.com/midwayjs/midway-faas/commit/37dd34feab822900af61d7515bc0a4cbed7b20f8))





## [0.3.2](https://github.com/midwayjs/midway-faas/compare/v0.3.1...v0.3.2) (2020-06-12)


### Features

* support url change ([#175](https://github.com/midwayjs/midway-faas/issues/175)) ([a2246b4](https://github.com/midwayjs/midway-faas/commit/a2246b4d792833be90314dcadf5af32d339e4e82))





## [0.3.1](https://github.com/midwayjs/midway-faas/compare/v0.3.0...v0.3.1) (2020-05-31)

**Note:** Version bump only for package @midwayjs/fcli-plugin-invoke





# [0.3.0](https://github.com/midwayjs/midway-faas/compare/v0.2.99...v0.3.0) (2020-05-26)

**Note:** Version bump only for package @midwayjs/fcli-plugin-invoke





## [0.2.99](https://github.com/midwayjs/midway-faas/compare/v0.2.98...v0.2.99) (2020-05-21)

**Note:** Version bump only for package @midwayjs/fcli-plugin-invoke





## [0.2.98](https://github.com/midwayjs/midway-faas/compare/v0.2.97...v0.2.98) (2020-05-18)

**Note:** Version bump only for package @midwayjs/fcli-plugin-invoke





## [0.2.97](https://github.com/midwayjs/midway-faas/compare/v0.2.96...v0.2.97) (2020-05-16)


### Bug Fixes

* fix windows path when invoke ([#169](https://github.com/midwayjs/midway-faas/issues/169)) ([e637a0a](https://github.com/midwayjs/midway-faas/commit/e637a0ab05a769a3797e2dccf0612bbbf650d074))





## [0.2.96](https://github.com/midwayjs/midway-faas/compare/v0.2.95...v0.2.96) (2020-05-16)

**Note:** Version bump only for package @midwayjs/fcli-plugin-invoke





## [0.2.95](https://github.com/midwayjs/midway-faas/compare/v0.2.94...v0.2.95) (2020-05-15)


### Features

* support debug by MIDWAY_FAAS_DEBUG ([#165](https://github.com/midwayjs/midway-faas/issues/165)) ([7c5cfc0](https://github.com/midwayjs/midway-faas/commit/7c5cfc0720fd3a6a58f4e30a477aa6500338f9b7))





## [0.2.94](https://github.com/midwayjs/midway-faas/compare/v0.2.93...v0.2.94) (2020-05-06)

**Note:** Version bump only for package @midwayjs/fcli-plugin-invoke





## [0.2.93](https://github.com/midwayjs/midway-faas/compare/v0.2.92...v0.2.93) (2020-05-05)

**Note:** Version bump only for package @midwayjs/fcli-plugin-invoke





## [0.2.92](https://github.com/midwayjs/midway-faas/compare/v0.2.91...v0.2.92) (2020-05-05)


### Bug Fixes

* entry ([#154](https://github.com/midwayjs/midway-faas/issues/154)) ([c3c745d](https://github.com/midwayjs/midway-faas/commit/c3c745de7716245656d4eb156e55bd79c7177e64))
* fix error control in fc ([#153](https://github.com/midwayjs/midway-faas/issues/153)) ([f7dd007](https://github.com/midwayjs/midway-faas/commit/f7dd0070f9c1b7f07e628c8d2052d273a8133910))





## [0.2.92-beta.1](https://github.com/midwayjs/midway-faas/compare/v0.2.91...v0.2.92-beta.1) (2020-05-04)

**Note:** Version bump only for package @midwayjs/fcli-plugin-invoke





## [0.2.91](https://github.com/midwayjs/midway-faas/compare/v0.2.90...v0.2.91) (2020-04-30)

**Note:** Version bump only for package @midwayjs/fcli-plugin-invoke





## [0.2.90](https://github.com/midwayjs/midway-faas/compare/v0.2.89...v0.2.90) (2020-04-29)

**Note:** Version bump only for package @midwayjs/fcli-plugin-invoke





## [0.2.89](https://github.com/midwayjs/midway-faas/compare/v0.2.88...v0.2.89) (2020-04-28)

**Note:** Version bump only for package @midwayjs/fcli-plugin-invoke





## [0.2.88](https://github.com/midwayjs/midway-faas/compare/v0.2.87...v0.2.88) (2020-04-26)

**Note:** Version bump only for package @midwayjs/fcli-plugin-invoke





## [0.2.87](https://github.com/midwayjs/midway-faas/compare/v0.2.86...v0.2.87) (2020-04-26)

**Note:** Version bump only for package @midwayjs/fcli-plugin-invoke





## [0.2.86](https://github.com/midwayjs/midway-faas/compare/v0.2.85...v0.2.86) (2020-04-24)

**Note:** Version bump only for package @midwayjs/fcli-plugin-invoke





## [0.2.85](https://github.com/midwayjs/midway-faas/compare/v0.2.84...v0.2.85) (2020-04-23)

**Note:** Version bump only for package @midwayjs/fcli-plugin-invoke





## [0.2.84](https://github.com/midwayjs/midway-faas/compare/v0.2.83...v0.2.84) (2020-04-23)


### Bug Fixes

* dev pack clean ([#141](https://github.com/midwayjs/midway-faas/issues/141)) ([d2731c8](https://github.com/midwayjs/midway-faas/commit/d2731c8bf8c662e06131eec80bdbc20474e39d89))





## [0.2.83](https://github.com/midwayjs/midway-faas/compare/v0.2.82...v0.2.83) (2020-04-23)


### Bug Fixes

* ts load dir ([#140](https://github.com/midwayjs/midway-faas/issues/140)) ([354c08c](https://github.com/midwayjs/midway-faas/commit/354c08cd6f7d50918f2393b8dddb90857735d5ac))





## [0.2.82](https://github.com/midwayjs/midway-faas/compare/v0.2.81...v0.2.82) (2020-04-23)


### Bug Fixes

* support typescript run ([#139](https://github.com/midwayjs/midway-faas/issues/139)) ([472c985](https://github.com/midwayjs/midway-faas/commit/472c985d054f452ed79b496d348a95adc754663e))





## [0.2.81](https://github.com/midwayjs/midway-faas/compare/v0.2.80...v0.2.81) (2020-04-22)

**Note:** Version bump only for package @midwayjs/fcli-plugin-invoke





## [0.2.79](https://github.com/midwayjs/midway-faas/compare/v0.2.78...v0.2.79) (2020-04-19)

**Note:** Version bump only for package @midwayjs/fcli-plugin-invoke





## [0.2.78](https://github.com/midwayjs/midway-faas/compare/v0.2.77...v0.2.78) (2020-04-18)

**Note:** Version bump only for package @midwayjs/fcli-plugin-invoke





## [0.2.77](https://github.com/midwayjs/midway-faas/compare/v0.2.76...v0.2.77) (2020-04-18)


### Features

* add dev pack ([#134](https://github.com/midwayjs/midway-faas/issues/134)) ([cd08f54](https://github.com/midwayjs/midway-faas/commit/cd08f54859da80f517cb37f99857679286f10f0f))





## [0.2.76](https://github.com/midwayjs/midway-faas/compare/v0.2.71...v0.2.76) (2020-04-16)


### Bug Fixes

* support apigw ([2321c08](https://github.com/midwayjs/midway-faas/commit/2321c08be4ed7a076aa6004df95a64f04db0ee6d))
* tencent trigger ([#131](https://github.com/midwayjs/midway-faas/issues/131)) ([0e93057](https://github.com/midwayjs/midway-faas/commit/0e93057205c2b761d1ee6fcf7e9c5d35bab349a7))





## [0.2.75](https://github.com/midwayjs/midway-faas/compare/v0.2.71...v0.2.75) (2020-04-15)


### Bug Fixes

* support apigw ([2321c08](https://github.com/midwayjs/midway-faas/commit/2321c08be4ed7a076aa6004df95a64f04db0ee6d))





## [0.2.74](https://github.com/midwayjs/midway-faas/compare/v0.2.73...v0.2.74) (2020-04-13)


### Bug Fixes

* support apigw ([abfc27a](https://github.com/midwayjs/midway-faas/commit/abfc27a93ae1b335bcb040679bbb5d39f71f5c9e))





## [0.2.73](https://github.com/midwayjs/midway-faas/compare/v0.2.73-alpha.0...v0.2.73) (2020-04-11)

**Note:** Version bump only for package @midwayjs/fcli-plugin-invoke





## [0.2.73-alpha.0](https://github.com/midwayjs/midway-faas/compare/v0.2.72...v0.2.73-alpha.0) (2020-04-11)

**Note:** Version bump only for package @midwayjs/fcli-plugin-invoke





## [0.2.72](https://github.com/midwayjs/midway-faas/compare/v0.2.71...v0.2.72) (2020-04-11)

**Note:** Version bump only for package @midwayjs/fcli-plugin-invoke





## [0.2.71](https://github.com/midwayjs/midway-faas/compare/v0.2.70...v0.2.71) (2020-04-10)


### Features

* introduce `experimentalFeatures` root option ([#123](https://github.com/midwayjs/midway-faas/issues/123)) ([e20417f](https://github.com/midwayjs/midway-faas/commit/e20417f11e8bcdada52ca9835adeec6c16b67c06))





## [0.2.70](https://github.com/midwayjs/midway-faas/compare/v0.2.69...v0.2.70) (2020-04-09)

**Note:** Version bump only for package @midwayjs/fcli-plugin-invoke





## [0.2.69](https://github.com/midwayjs/midway-faas/compare/v0.2.68...v0.2.69) (2020-04-08)


### Bug Fixes

* load spec ([#119](https://github.com/midwayjs/midway-faas/issues/119)) ([66df38c](https://github.com/midwayjs/midway-faas/commit/66df38c221c033cf1ba9e28fcdc9953e33aabf34))
* serverless invoke ([#117](https://github.com/midwayjs/midway-faas/issues/117)) ([e6e37af](https://github.com/midwayjs/midway-faas/commit/e6e37af83856292d8e54896a0c3543cc50aba86e))





## [0.2.68](https://github.com/midwayjs/midway-faas/compare/v0.2.67...v0.2.68) (2020-04-07)


### Bug Fixes

* invoke missing cwd ([#116](https://github.com/midwayjs/midway-faas/issues/116)) ([424e08b](https://github.com/midwayjs/midway-faas/commit/424e08bf63e8ce31d8f50b234d3c6beb00a05c9a))





## [0.2.67](https://github.com/midwayjs/midway-faas/compare/v0.2.66...v0.2.67) (2020-04-07)


### Bug Fixes

* invoke hooks ([#113](https://github.com/midwayjs/midway-faas/issues/113)) ([765ec7e](https://github.com/midwayjs/midway-faas/commit/765ec7e259775360ff0c26755bdf78843b3658bf))





## [0.2.66](https://github.com/midwayjs/midway-faas/compare/v0.2.65...v0.2.66) (2020-04-06)


### Bug Fixes

* invoke getFuncList and core auto load plugin ([#112](https://github.com/midwayjs/midway-faas/issues/112)) ([54e4d11](https://github.com/midwayjs/midway-faas/commit/54e4d1151942075b86d187c46fc107b9ff1d816b))





## [0.2.65](https://github.com/midwayjs/midway-faas/compare/v0.2.64...v0.2.65) (2020-04-05)


### Bug Fixes

* core support stop ([#111](https://github.com/midwayjs/midway-faas/issues/111)) ([4ecf423](https://github.com/midwayjs/midway-faas/commit/4ecf423dc2b0366b90b2d40b39a229421d4ee006)), closes [#107](https://github.com/midwayjs/midway-faas/issues/107)





## [0.2.64](https://github.com/midwayjs/midway-faas/compare/v0.2.63...v0.2.64) (2020-04-05)

**Note:** Version bump only for package @midwayjs/fcli-plugin-invoke





## [0.2.63](https://github.com/midwayjs/midway-faas/compare/v0.2.62...v0.2.63) (2020-04-03)


### Bug Fixes

* invoke bug ([#110](https://github.com/midwayjs/midway-faas/issues/110)) ([7c2d000](https://github.com/midwayjs/midway-faas/commit/7c2d000404cb185ff8597e9b3acea2a0955f1bda))





## [0.2.62](https://github.com/midwayjs/midway-faas/compare/v0.2.61...v0.2.62) (2020-04-03)


### Bug Fixes

* code ana package ([#108](https://github.com/midwayjs/midway-faas/issues/108)) ([6e11d0f](https://github.com/midwayjs/midway-faas/commit/6e11d0f588e10b41551256a23a7d4fd6b8133c93))
* invoke bug ([#106](https://github.com/midwayjs/midway-faas/issues/106)) ([d45ff3f](https://github.com/midwayjs/midway-faas/commit/d45ff3f3c41764d08c6968dbdd676d174b695d96))


### Features

* introduce mwcc integration ([#103](https://github.com/midwayjs/midway-faas/issues/103)) ([40f458c](https://github.com/midwayjs/midway-faas/commit/40f458cf2c10903c03a93362cd691c04d97f91cd))





## [0.2.61](https://github.com/midwayjs/midway-faas/compare/v0.2.60...v0.2.61) (2020-03-31)


### Bug Fixes

* core hooks ([#104](https://github.com/midwayjs/midway-faas/issues/104)) ([ac6b574](https://github.com/midwayjs/midway-faas/commit/ac6b574b7bab95358d5f14214711390959ad56b6))





## [0.2.60](https://github.com/midwayjs/midway-faas/compare/v0.2.59...v0.2.60) (2020-03-31)

**Note:** Version bump only for package @midwayjs/fcli-plugin-invoke





## [0.2.59](https://github.com/midwayjs/midway-faas/compare/v0.2.58...v0.2.59) (2020-03-30)

**Note:** Version bump only for package @midwayjs/fcli-plugin-invoke





## [0.2.58](https://github.com/midwayjs/midway-faas/compare/v0.2.57...v0.2.58) (2020-03-30)


### Features

* new invoke ([#101](https://github.com/midwayjs/midway-faas/issues/101)) ([4c13a69](https://github.com/midwayjs/midway-faas/commit/4c13a695d9443f0f6683cad28967157f0d2ab496))





## [0.2.57](https://github.com/midwayjs/midway-faas/compare/v0.2.56...v0.2.57) (2020-03-27)

**Note:** Version bump only for package @midwayjs/fcli-plugin-invoke





## [0.2.56](https://github.com/midwayjs/midway-faas/compare/v0.2.55...v0.2.56) (2020-03-23)

**Note:** Version bump only for package @midwayjs/fcli-plugin-invoke





## [0.2.55](https://github.com/midwayjs/midway-faas/compare/v0.2.54...v0.2.55) (2020-03-20)

**Note:** Version bump only for package @midwayjs/fcli-plugin-invoke





## [0.2.54](https://github.com/midwayjs/midway-faas/compare/v0.2.53...v0.2.54) (2020-03-19)

**Note:** Version bump only for package @midwayjs/fcli-plugin-invoke





## [0.2.53](https://github.com/midwayjs/midway-faas/compare/v0.2.52...v0.2.53) (2020-03-18)

**Note:** Version bump only for package @midwayjs/fcli-plugin-invoke





## [0.2.52](https://github.com/midwayjs/midway-faas/compare/v0.2.51...v0.2.52) (2020-03-17)

**Note:** Version bump only for package @midwayjs/fcli-plugin-invoke





## [0.2.51](https://github.com/midwayjs/midway-faas/compare/v0.2.50...v0.2.51) (2020-03-17)

**Note:** Version bump only for package @midwayjs/fcli-plugin-invoke





## [0.2.50](https://github.com/midwayjs/midway-faas/compare/v0.2.49...v0.2.50) (2020-03-17)

**Note:** Version bump only for package @midwayjs/fcli-plugin-invoke





## [0.2.49](https://github.com/midwayjs/midway-faas/compare/v0.2.48...v0.2.49) (2020-03-14)

**Note:** Version bump only for package @midwayjs/fcli-plugin-invoke





## [0.2.48](https://github.com/midwayjs/midway-faas/compare/v0.2.47...v0.2.48) (2020-03-13)

**Note:** Version bump only for package @midwayjs/fcli-plugin-invoke





## [0.2.46](https://github.com/midwayjs/midway-faas/compare/v0.2.45...v0.2.46) (2020-03-11)

**Note:** Version bump only for package @midwayjs/fcli-plugin-invoke





## [0.2.45](https://github.com/midwayjs/midway-faas/compare/v0.2.44...v0.2.45) (2020-03-11)

**Note:** Version bump only for package @midwayjs/fcli-plugin-invoke





## [0.2.42](https://github.com/midwayjs/midway-faas/compare/v0.2.41...v0.2.42) (2020-03-06)

**Note:** Version bump only for package @midwayjs/fcli-plugin-invoke





## [0.2.41](https://github.com/midwayjs/midway-faas/compare/v0.2.40...v0.2.41) (2020-03-06)


### Features

* command core store ([#72](https://github.com/midwayjs/midway-faas/issues/72)) ([10e68a9](https://github.com/midwayjs/midway-faas/commit/10e68a9a1cf096628eabb7b2b3f2c34dbdd14f3a))





## [0.2.40](https://github.com/midwayjs/midway-faas/compare/v0.2.39...v0.2.40) (2020-03-02)

**Note:** Version bump only for package @midwayjs/fcli-plugin-invoke





## [0.2.39](https://github.com/midwayjs/midway-faas/compare/v0.2.38...v0.2.39) (2020-03-02)

**Note:** Version bump only for package @midwayjs/fcli-plugin-invoke





## [0.2.37](https://github.com/midwayjs/midway-faas/compare/v0.2.36...v0.2.37) (2020-02-29)

**Note:** Version bump only for package @midwayjs/fcli-plugin-invoke





## [0.2.36](https://github.com/midwayjs/midway-faas/compare/v0.2.35...v0.2.36) (2020-02-28)

**Note:** Version bump only for package @midwayjs/fcli-plugin-invoke





## [0.2.35](https://github.com/midwayjs/midway-faas/compare/v0.2.34...v0.2.35) (2020-02-26)

**Note:** Version bump only for package @midwayjs/fcli-plugin-invoke





## [0.2.34](https://github.com/midwayjs/midway-faas/compare/v0.2.33...v0.2.34) (2020-02-26)


### Bug Fixes

* file compare & npm options ([#62](https://github.com/midwayjs/midway-faas/issues/62)) ([beb50f8](https://github.com/midwayjs/midway-faas/commit/beb50f85106cd627aac7b2ab0317ed29ae830e33))





## [0.2.33](https://github.com/midwayjs/midway-faas/compare/v0.2.32...v0.2.33) (2020-02-24)

**Note:** Version bump only for package @midwayjs/fcli-plugin-invoke





## [0.2.32](https://github.com/midwayjs/midway-faas/compare/v0.2.31...v0.2.32) (2020-02-23)

**Note:** Version bump only for package @midwayjs/fcli-plugin-invoke





## [0.2.31](https://github.com/midwayjs/midway-faas/compare/v0.2.30...v0.2.31) (2020-02-23)

**Note:** Version bump only for package @midwayjs/fcli-plugin-invoke





## [0.2.30](https://github.com/midwayjs/midway-faas/compare/v0.2.29...v0.2.30) (2020-02-22)

**Note:** Version bump only for package @midwayjs/fcli-plugin-invoke





## [0.2.29](https://github.com/midwayjs/midway-faas/compare/v0.2.28...v0.2.29) (2020-02-22)

**Note:** Version bump only for package @midwayjs/fcli-plugin-invoke





## [0.2.27](https://github.com/midwayjs/midway-faas/compare/v0.2.26...v0.2.27) (2020-02-21)


### Bug Fixes

* invoke source map ([#52](https://github.com/midwayjs/midway-faas/issues/52)) ([9149d2a](https://github.com/midwayjs/midway-faas/commit/9149d2a9a3f3d9ba975588b61c6f9bbeec2e8d86)), closes [#51](https://github.com/midwayjs/midway-faas/issues/51)





## [0.2.25](https://github.com/midwayjs/midway-faas/compare/v0.2.24...v0.2.25) (2020-02-19)

**Note:** Version bump only for package @midwayjs/fcli-plugin-invoke





## [0.2.24](https://github.com/midwayjs/midway-faas/compare/v0.2.23...v0.2.24) (2020-02-18)

**Note:** Version bump only for package @midwayjs/fcli-plugin-invoke





## [0.2.23](https://github.com/midwayjs/midway-faas/compare/v0.2.22...v0.2.23) (2020-02-17)

**Note:** Version bump only for package @midwayjs/fcli-plugin-invoke





## [0.2.22](https://github.com/midwayjs/midway-faas/compare/v0.2.21...v0.2.22) (2020-02-17)

**Note:** Version bump only for package @midwayjs/fcli-plugin-invoke





## [0.2.20](https://github.com/midwayjs/midway-faas/compare/v0.2.19...v0.2.20) (2020-02-11)

**Note:** Version bump only for package @midwayjs/fcli-plugin-invoke





## [0.2.19](https://github.com/midwayjs/midway-faas/compare/v0.2.18...v0.2.19) (2020-02-10)

**Note:** Version bump only for package @midwayjs/fcli-plugin-invoke





## [0.2.18](https://github.com/midwayjs/midway-faas/compare/v0.2.17...v0.2.18) (2020-02-08)

**Note:** Version bump only for package @midwayjs/fcli-plugin-invoke





## [0.2.17](https://github.com/midwayjs/midway-faas/compare/v0.2.16...v0.2.17) (2020-02-05)

**Note:** Version bump only for package @midwayjs/fcli-plugin-invoke





## [0.2.16](https://github.com/midwayjs/midway-faas/compare/v0.2.15...v0.2.16) (2020-02-04)

**Note:** Version bump only for package @midwayjs/fcli-plugin-invoke





## [0.2.15](https://github.com/midwayjs/midway-faas/compare/v0.2.14...v0.2.15) (2020-02-04)

**Note:** Version bump only for package @midwayjs/fcli-plugin-invoke





## [0.2.14](https://github.com/midwayjs/midway-faas/compare/v0.2.13...v0.2.14) (2020-02-01)

**Note:** Version bump only for package @midwayjs/fcli-plugin-invoke





## [0.2.13](https://github.com/midwayjs/midway-faas/compare/v0.2.12...v0.2.13) (2020-01-21)

**Note:** Version bump only for package @midwayjs/fcli-plugin-invoke





## [0.2.11](https://github.com/midwayjs/midway-faas/compare/v0.2.10...v0.2.11) (2020-01-20)

**Note:** Version bump only for package @midwayjs/fcli-plugin-invoke





## [0.2.10](https://github.com/midwayjs/midway-faas/compare/v0.2.9...v0.2.10) (2020-01-16)


### Bug Fixes

* refactor appregation & pass process env to invoke debug ([#24](https://github.com/midwayjs/midway-faas/issues/24)) ([f8cd981](https://github.com/midwayjs/midway-faas/commit/f8cd98118e91d3e1b15c2b37d1aaad6b15282f26))





## [0.2.7](https://github.com/midwayjs/midway-faas/compare/v0.2.6...v0.2.7) (2020-01-14)

**Note:** Version bump only for package @midwayjs/fcli-plugin-invoke





## [0.2.6](https://github.com/midwayjs/midway-faas/compare/v0.2.5...v0.2.6) (2020-01-14)

**Note:** Version bump only for package @midwayjs/fcli-plugin-invoke





## [0.2.4](https://github.com/midwayjs/midway-faas/compare/v0.2.3...v0.2.4) (2020-01-09)


### Features

* single process invoke and debug ([#16](https://github.com/midwayjs/midway-faas/issues/16)) ([826a8c7](https://github.com/midwayjs/midway-faas/commit/826a8c7a7a36d8ec03a84f3d29498bef58811146))





## [0.2.2](https://github.com/midwayjs/midway-faas/compare/v0.2.1...v0.2.2) (2020-01-08)

**Note:** Version bump only for package @midwayjs/fcli-plugin-invoke







**Note:** Version bump only for package @midwayjs/fcli-plugin-invoke





## [0.2.1](https://github.com/midwayjs/midway-faas/compare/v0.2.0...v0.2.1) (2020-01-06)

**Note:** Version bump only for package @midwayjs/fcli-plugin-invoke





# [0.2.0](https://github.com/midwayjs/midway-faas/compare/v0.1.12...v0.2.0) (2020-01-05)

**Note:** Version bump only for package @midwayjs/fcli-plugin-invoke





## [0.1.12](https://github.com/midwayjs/midway-faas/compare/v0.1.11...v0.1.12) (2020-01-01)


### Bug Fixes

* command-core point and writeSpec ([d0dac1e](https://github.com/midwayjs/midway-faas/commit/d0dac1e41e783746b857eebcd9e4730e37737d72))
* invoke user runtime ([7e5ab36](https://github.com/midwayjs/midway-faas/commit/7e5ab3636523d13b79527c2f0edd5fb405550d5f))





## [0.1.11](https://github.com/midwayjs/midway-faas/compare/v0.1.10...v0.1.11) (2019-12-30)


### Bug Fixes

* faas-cli use aliCli ([3e9e89b](https://github.com/midwayjs/midway-faas/commit/3e9e89b8ecbd326e15a5e95e7f48ed1c0c9ccc4d))





## [0.1.10](https://github.com/midwayjs/midway-faas/compare/v0.1.9...v0.1.10) (2019-12-27)


### Bug Fixes

* remove faas-plugin-common ([41351f9](https://github.com/midwayjs/midway-faas/commit/41351f9f974e6551e80207a133e77582cc06dfdc))





## [0.1.9](https://github.com/midwayjs/midway-faas/compare/v0.1.8...v0.1.9) (2019-12-27)


### Bug Fixes

* change faas-local name ([f1dc443](https://github.com/midwayjs/midway-faas/commit/f1dc4437451c9459171dce3cba72491e2f743bb9))
* common-cli add extensions ([abfe339](https://github.com/midwayjs/midway-faas/commit/abfe3395d3cd42cf9dea8f0e91238b2d5583f2a6))
