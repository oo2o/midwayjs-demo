
0.0.5 / 2020-04-30
==================



0.0.4 / 2020-04-30
==================

  * fix: add options exit
  * check extensions is empty
  * fix: check extensions is empty
  * Release 0.0.1
  * docs: readme
  * feat: new
