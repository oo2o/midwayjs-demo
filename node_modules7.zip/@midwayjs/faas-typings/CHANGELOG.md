# Change Log

All notable changes to this project will be documented in this file.
See [Conventional Commits](https://conventionalcommits.org) for commit guidelines.

## [1.1.4](https://github.com/midwayjs/midway-faas/compare/v1.0.8...v1.1.4) (2020-07-24)


### Features

* default add cookie for http parser ([#540](https://github.com/midwayjs/midway-faas/issues/540)) ([5799e96](https://github.com/midwayjs/midway-faas/commit/5799e9642144b23b81d5c629387ce52510dde00d))
* Support application layer ([#534](https://github.com/midwayjs/midway-faas/issues/534)) ([7a141c0](https://github.com/midwayjs/midway-faas/commit/7a141c0c9404dc20d4d146a14e01dff404943142))





# [1.1.0](https://github.com/midwayjs/midway-faas/compare/serverless-v1.0.11...serverless-v1.1.0) (2020-07-21)


### Features

* Support application layer ([#534](https://github.com/midwayjs/midway-faas/issues/534)) ([7a141c0](https://github.com/midwayjs/midway-faas/commit/7a141c0c9404dc20d4d146a14e01dff404943142))





## [1.0.11](https://github.com/midwayjs/midway-faas/compare/serverless-v1.0.10...serverless-v1.0.11) (2020-07-21)


### Features

* default add cookie for http parser ([#540](https://github.com/midwayjs/midway-faas/issues/540)) ([5799e96](https://github.com/midwayjs/midway-faas/commit/5799e9642144b23b81d5c629387ce52510dde00d))





## 1.0.7 (2020-07-14)


### Bug Fixes

* fix missing typings ([#171](https://github.com/midwayjs/midway-faas/issues/171)) ([1d40cf1](https://github.com/midwayjs/midway-faas/commit/1d40cf1c1d76f45888b4ce15f9a2151b81c7a8f9))


### Features

* aws support ([#526](https://github.com/midwayjs/midway-faas/issues/526)) ([9da022e](https://github.com/midwayjs/midway-faas/commit/9da022ecdf1e7770c21705131679940adc67ff3c))
* support koa app create ([#173](https://github.com/midwayjs/midway-faas/issues/173)) ([c3793eb](https://github.com/midwayjs/midway-faas/commit/c3793eba182f634684fdaf147981433bb64639a1))





## 1.0.1 (2020-07-06)


### Bug Fixes

* fix missing typings ([#171](https://github.com/midwayjs/midway-faas/issues/171)) ([1d40cf1](https://github.com/midwayjs/midway-faas/commit/1d40cf1c1d76f45888b4ce15f9a2151b81c7a8f9))


### Features

* support koa app create ([#173](https://github.com/midwayjs/midway-faas/issues/173)) ([c3793eb](https://github.com/midwayjs/midway-faas/commit/c3793eba182f634684fdaf147981433bb64639a1))





# 1.0.0 (2020-07-02)


### Bug Fixes

* fix missing typings ([#171](https://github.com/midwayjs/midway-faas/issues/171)) ([1d40cf1](https://github.com/midwayjs/midway-faas/commit/1d40cf1c1d76f45888b4ce15f9a2151b81c7a8f9))


### Features

* support koa app create ([#173](https://github.com/midwayjs/midway-faas/issues/173)) ([c3793eb](https://github.com/midwayjs/midway-faas/commit/c3793eba182f634684fdaf147981433bb64639a1))





# [0.3.0](https://github.com/midwayjs/midway-faas/compare/v0.2.99...v0.3.0) (2020-05-26)


### Features

* support koa app create ([#173](https://github.com/midwayjs/midway-faas/issues/173)) ([c3793eb](https://github.com/midwayjs/midway-faas/commit/c3793eba182f634684fdaf147981433bb64639a1))





## [0.2.99](https://github.com/midwayjs/midway-faas/compare/v0.2.98...v0.2.99) (2020-05-21)


### Bug Fixes

* fix missing typings ([#171](https://github.com/midwayjs/midway-faas/issues/171)) ([1d40cf1](https://github.com/midwayjs/midway-faas/commit/1d40cf1c1d76f45888b4ce15f9a2151b81c7a8f9))





## [0.2.95](https://github.com/midwayjs/midway-faas/compare/v0.2.94...v0.2.95) (2020-05-15)

**Note:** Version bump only for package @midwayjs/faas-typings





## [0.2.89](https://github.com/midwayjs/midway-faas/compare/v0.2.88...v0.2.89) (2020-04-28)

**Note:** Version bump only for package @midwayjs/faas-typings





## [0.2.88](https://github.com/midwayjs/midway-faas/compare/v0.2.87...v0.2.88) (2020-04-26)

**Note:** Version bump only for package @midwayjs/faas-typings





## [0.2.87](https://github.com/midwayjs/midway-faas/compare/v0.2.86...v0.2.87) (2020-04-26)

**Note:** Version bump only for package @midwayjs/faas-typings
