
1.0.6 / 2020-06-29
==================

  * fix: fix replace wrong directory name (#3)

1.0.5 / 2020-06-29
==================

  * npm: add homepage and repository (#2)

1.0.4 / 2020-06-28
==================

  * fix: fix dot directory in cwd (#1)
  * chore: update pkg

1.0.3 / 2020-06-17
==================

  * chore: add timing

1.0.2 / 2020-06-16
==================

  * refactor: fix midway app glob
