export * from '@midwayjs/fcli-plugin-invoke';
