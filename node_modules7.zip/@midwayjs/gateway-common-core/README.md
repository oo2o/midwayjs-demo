# @midwayjs/gateway-common-core

网关通用类库或依赖
