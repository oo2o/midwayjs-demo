# egg-ts-helper for midway

支持在 midway 中生成 ts 定义。

fork from https://github.com/whxaxes/egg-ts-helper
