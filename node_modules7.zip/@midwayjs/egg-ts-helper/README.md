# egg-ts-helper for midway

support generate egg ts definition in midway project

fork from https://github.com/whxaxes/egg-ts-helper
