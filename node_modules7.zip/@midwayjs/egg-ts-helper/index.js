module.exports = require('egg-ts-helper');
