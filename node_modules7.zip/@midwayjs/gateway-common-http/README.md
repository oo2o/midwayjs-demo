# @midwayjs/gateway-common-http

http 网关模拟
