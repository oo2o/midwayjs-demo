
2.0.1 / 2017-02-09
==================

  * fix: it should reject error when ready return promise (#3)

2.0.0 / 2017-02-08
==================

  * feat: [BREAKING_CHANGE] reimplement get-ready (#2)
  * fix typo on readme

1.0.0 / 2015-09-29
==================

 * chore: use eslint and es6
 * test: add test with co
 * travis: test on node(1,2,3,4)
 * feat: support promise
 * fork from supershabam/ready
