export interface TypeHelpOptions {
    newObject: any;
    object: Record<string, any>;
    property: string;
}
