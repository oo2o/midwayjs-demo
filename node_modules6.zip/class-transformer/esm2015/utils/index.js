export * from './get-global.util';
//# sourceMappingURL=index.js.map