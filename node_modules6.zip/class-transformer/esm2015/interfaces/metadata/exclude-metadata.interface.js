export {};
//# sourceMappingURL=exclude-metadata.interface.js.map