export {};
//# sourceMappingURL=expose-metadata.interface.js.map