export {};
//# sourceMappingURL=transform-metadata.interface.js.map