export {};
//# sourceMappingURL=class-constructor.type.js.map