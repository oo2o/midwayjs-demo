export {};
//# sourceMappingURL=transform-options.interface.js.map