export {};
//# sourceMappingURL=expose-options.interface.js.map