export {};
//# sourceMappingURL=type-options.interface.js.map