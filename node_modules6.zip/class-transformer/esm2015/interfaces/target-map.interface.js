export {};
//# sourceMappingURL=target-map.interface.js.map