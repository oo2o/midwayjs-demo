'use strict';

exports = module.exports = require('./lib/any');
exports.json = require('./lib/json');
exports.form = require('./lib/form');
exports.text = require('./lib/text');
