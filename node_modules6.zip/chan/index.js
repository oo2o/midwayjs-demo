/**
 * Module dependencies.
 */
var make   = require('./lib/make')
var select = require('./lib/select')

/**
 * Expose `make`.
 */
module.exports = make

/**
 * Expose `select`.
 */
module.exports.select = select
