import flatten = require('array-flatten');
export declare type Next<T = void> = (err?: Error | null) => T;
export declare type RequestHandler<T, U, V = void> = (req: T, res: U, next: Next<V>) => V;
export declare type ErrorHandler<T, U, V = void> = (err: Error, req: T, res: U, next: Next<V>) => V;
export declare type Middleware<T, U, V = void> = RequestHandler<T, U, V> | ErrorHandler<T, U, V>;
export declare type Handler<T, U, V = void> = Middleware<T, U, V> | flatten.NestedArray<Middleware<T, U, V>>;
/**
 * Compose an array of middleware handlers into a single handler.
 */
export declare function compose<T, U, V = void>(...handlers: Handler<T, U, V>[]): RequestHandler<T, U, V>;
/**
 * Wrap middleware handlers.
 */
export declare function errors<T, U, V = void>(...handlers: Handler<T, U, V>[]): ErrorHandler<T, U, V>;
