
2.9.0 / 2020-07-03
==================

**features**
  * [[`34cad2a`](http://github.com/node-modules/common-bin/commit/34cad2ad20781ec671bc8d7b846a1de1a1e3fc2a)] - feat: expose proc (#42) (TZ | 天猪 <<atian25@qq.com>>)

**fixes**
  * [[`b2c6dac`](http://github.com/node-modules/common-bin/commit/b2c6dacfb62500163f8495d765ff9586d0ad08be)] - fix(typings): add type for options (#41) (DiamondYuan <<541832074@qq.com>>)

2.8.3 / 2019-12-26
==================

**fixes**
  * [[`ca3fc44`](http://github.com/node-modules/common-bin/commit/ca3fc4476375661fc6aa9bcd84debbeadbe7f063)] - fix: --require support relative path (#38) (TZ | 天猪 <<atian25@qq.com>>)
  * [[`d2c9ca2`](http://github.com/node-modules/common-bin/commit/d2c9ca2fc7de71624e986eccd9eb273607dc0324)] - fix: parserOptions property name error (#32) (Nick Teng <<tenpend@outlook.com>>)
  * [[`60d25b2`](http://github.com/node-modules/common-bin/commit/60d25b252dc2a89e945c252dfb6c257a518ffc7c)] - fix: commonBin class contructor arwArgv optional (#30) (liuqipeng <<liuqipeng417@outlook.com>>)

2.8.2 / 2019-08-08
==================

**fixes**
  * [[`f0f4b64`](http://github.com/node-modules/common-bin/commit/f0f4b64726656f8a0416ada7c3e6bc85cebae50d)] - fix: support es module (#35) (hacke2 <<hacke2cn@gmail.com>>)

**others**
  * [[`25025a1`](http://github.com/node-modules/common-bin/commit/25025a166f783d606d6c94831841d06241253736)] -  chore: add notice of WebStorm 2019 (#31) (TZ | 天猪 <<atian25@qq.com>>)

2.8.1 / 2018-12-29
==================

  * feat: add typescript support (#28)

2.8.0 / 2018-10-11
==================

  * feat: allow to set helper (#27)
  * feat: use `--node-options--xxx` to support more execArgv (#23)
  * deps: upgrade yargs@8 -> 12 (#26)

2.7.3 / 2018-03-27
==================

  * fix: --require (#21)

2.7.2 / 2018-03-26
==================

**fixes**
  * [[`037b1d0`](http://github.com/node-modules/common-bin/commit/037b1d02e33beebf2071fe68c235593cea8e2c42)] - fix: execArgv convert rule (#20) (TZ | 天猪 <<atian25@qq.com>>)

2.7.1 / 2017-09-18
==================

  * fix: warn expose_debug_as at 7.x+ (#17)

2.7.0 / 2017-09-05
==================

**features**
  * [[`a90e63c`](http://github.com/node-modules/common-bin/commit/a90e63c653d34634290a0af81bf358521457cff8)] - feat: extract debug options (#16) (TZ | 天猪 <<atian25@qq.com>>)

2.6.1 / 2017-08-30
==================

**fixes**
  * [[`aa4799c`](http://github.com/node-modules/common-bin/commit/aa4799cad621e399a3a168e6d6a07b3fdb407d01)] - fix: remove unuse argv (#15) (TZ | 天猪 <<atian25@qq.com>>)

2.6.0 / 2017-08-15
==================

**features**
  * [[`58506ff`](http://github.com/node-modules/common-bin/commit/58506ffb45299b0027de9c3a37fa4d8cd5f809ae)] - feat: version support lazy load (#14) (Yiyu He <<dead_horse@qq.com>>)

2.5.0 / 2017-08-04
==================

**features**
  * [[`6eed130`](http://github.com/node-modules/common-bin/commit/6eed1303caf5aeef4306f503adcae458e9093b92)] - feat: support customize version (#13) (Yiyu He <<dead_horse@qq.com>>)

2.4.0 / 2017-06-04
==================

  * fix: should show error name and message
  * feat: exports env on context

2.3.1 / 2017-05-06
==================

  * refactor: better error message (#11)

2.3.0 / 2017-04-15
==================

  * feat: support parserOptions (#10)

2.2.0 / 2017-03-21
==================

  * feat(helper): add unparseArgv and spawn (#9)

2.1.0 / 2017-03-17
==================

  * feat: add with class & normalizeContext (#8)

2.0.0 / 2017-03-16
==================

  * feat: call DISPATCH directly & auto complete (#7)
  * feat: [BREAKING_CHANGE] reimplement to support subcommand and options (#6)

1.0.1 / 2017-02-04
==================

  * fix: add "More commands" in help info (#2)
  * docs: egg-bin -> common-bin

1.0.0 / 2016-07-28
==================

  * init version
