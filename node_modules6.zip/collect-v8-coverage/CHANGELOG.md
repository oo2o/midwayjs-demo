## [1.0.1](https://github.com/SimenB/collect-v8-coverage/compare/v1.0.0...v1.0.1) (2020-04-02)

### Bug Fixes

- link to repo from package.json ([cf54d65](https://github.com/SimenB/collect-v8-coverage/commit/cf54d659f23afd411cd0ff752e69fa97d2ab1707))

# 1.0.0 (2019-12-16)

### Features

- initial commit ([57e2041](https://github.com/SimenB/collect-v8-coverage/commit/57e20413f385d7730c5684b1852c14777583807e))
