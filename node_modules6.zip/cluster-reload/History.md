
1.0.2 / 2015-12-23
==================

  * fix: Windows not support SIGQUIT, use SIGTERM instead

1.0.1 / 2015-06-30
==================

 * fix: make sure child worker kill itself

1.0.0 / 2015-06-03
==================

 * first commit
