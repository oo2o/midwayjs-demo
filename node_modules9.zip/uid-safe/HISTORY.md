2.1.5 / 2017-08-02
==================

  * perf: remove only trailing `=`

2.1.4 / 2017-03-02
==================

  * Remove `base64-url` dependency

2.1.3 / 2016-10-30
==================

  * deps: base64-url@1.3.3

2.1.2 / 2016-08-15
==================

  * deps: base64-url@1.3.2

2.1.1 / 2016-05-04
==================

  * deps: base64-url@1.2.2

2.1.0 / 2016-01-17
==================

  * Use `random-bytes` for byte source

2.0.0 / 2015-05-08
==================

  * Use global `Promise` when returning a promise

1.1.0 / 2015-02-01
==================

  * Use `crypto.randomBytes`, if available
  * deps: base64-url@1.2.1

1.0.3 / 2015-01-31
==================

  * Fix error branch that would throw
  * deps: base64-url@1.2.0

1.0.2 / 2015-01-08
==================

  * Remove dependency on `mz`

1.0.1 / 2014-06-18
==================

  * Remove direct `bluebird` dependency

1.0.0 / 2014-06-18
==================

  * Initial release
