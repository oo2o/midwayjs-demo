
1.1.0 / 2016-12-13
==================

  * fix: add setMaxListeners to padStream (#2)

1.0.0 / 2016-11-29
==================

First Version

