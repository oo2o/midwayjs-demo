
1.2.0 / 2018-04-19
==================

**features**
  * [[`0bdc868`](http://github.com/node-modules/wt/commit/0bdc868fa8ecc73e595369ad72f1e4b98ec1c258)] - feat: add `ignoreNodeModules` options for ignoring node_modules directory (#9) (ZhengFang <<215566435@qq.com>>)

**others**
  * [[`26e8766`](http://github.com/node-modules/wt/commit/26e8766cea17acae41923a72f1371039a31c328d)] - test: use mocha@3 to support node 0.12 (#10) (fengmk2 <<fengmk2@gmail.com>>)

1.1.1 / 2016-03-23
==================

  * deps: use rimraf
  * fix: watch event name will be undefined

1.1.0 / 2015-05-14
==================

 * deps: debug@2.2.0
 * test: improve test coverage
 * feat: support auto rewatch root dir

1.0.0 / 2015-05-07
==================

 * improve: do not pass dirs when instantiation

0.2.1 / 2014-11-11
==================

 * add missing argument for factory function (@luckydrq)

0.2.0 / 2014-06-16
==================

 * ignore hidden file by defaults. close #1

0.1.0 / 2014-05-20
==================

 * only test remove on remove file
 * filter repeat event
 * rm file will cause other change on linux
 * rm dir will cause other change on linux
 * fix repeat event on linux
 * support recursive on linux platform

0.0.2 / 2014-05-20
==================

 * support multi dirs

0.0.1 / 2014-05-20
==================

 * first version
