
1.2.1 / 2018-07-11
==================

**others**
  * [[`475abb0`](http://github.com/node-modules/ylru/commit/475abb0e9c787fd65d7c3dd3d2d74d67560b0bec)] - perf: only call Date.now() when necessary (#3) (Yiyu He <<dead_horse@qq.com>>)

1.2.0 / 2017-07-18
==================

  * feat: support lru.keys (#2)

1.1.0 / 2017-07-04
==================

  * feat: support get with maxAge (#1)

1.0.0 / 2016-12-29
==================

 * init version

