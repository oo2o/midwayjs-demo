### [1.2.2](https://github.com/twada/universal-deep-strict-equal/releases/tag/v1.2.2) (2016-07-11)


  * [Sync with Node v6.3.0](https://github.com/twada/universal-deep-strict-equal/pull/9)


### [1.2.1](https://github.com/twada/universal-deep-strict-equal/releases/tag/v1.2.1) (2016-05-06)


#### Bug Fixes

  * [Dealing with old IE that doesn't have Arguments](https://github.com/twada/universal-deep-strict-equal/pull/7)


## [1.2.0](https://github.com/twada/universal-deep-strict-equal/releases/tag/v1.2.0) (2016-05-06)


#### Features

  * [Allow circular references](https://github.com/twada/universal-deep-strict-equal/pull/4) by [@azu](https://github.com/azu)


## [1.1.0](https://github.com/twada/universal-deep-strict-equal/releases/tag/v1.1.0) (2016-05-06)


#### Features

  * [Support old browsers](https://github.com/twada/universal-deep-strict-equal/pull/2)


## [1.0.0](https://github.com/twada/universal-deep-strict-equal/releases/tag/v1.0.0) (2016-05-04)


#### Features

  * the first stable release


## [0.1.0](https://github.com/twada/universal-deep-strict-equal/releases/tag/v0.1.0) (2016-05-03)


#### Features

  * initial release
