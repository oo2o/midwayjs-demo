## v1.0.8 (2020-07-27)

[Allow default imports in TS #200](https://github.com/leizongmin/js-xss/pull/200) by @danvk
[Update handling of quoteStart to prevent sanitization bypass #201](https://github.com/leizongmin/js-xss/pull/201) by @TomAnthony

## v1.0.7 (2020-06-08)

[added support for src embedded image, ftp and relative urls](https://github.com/leizongmin/js-xss/pull/189) by @sijanec
