module.exports = require('./lib/vizion.js');
