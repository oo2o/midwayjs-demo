
# 0.2.12

- Increase buffer size
- Upgrade .travis.yml
